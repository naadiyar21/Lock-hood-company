module.exports = {
    env: {
        node: true,
    },
    extends: ["eslint:recommended", "plugin:vue/vue3-recommended", "prettier"],
    rules: {
        "no-unused-vars": "off",
        "vue/no-mutating-props": "off",
    },
    globals: { _: true },
};
