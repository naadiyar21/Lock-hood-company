<?php

use App\Http\Controllers\AccessLevelController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\FactoryController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\NotificationUserController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\WorkshopController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware('auth:sanctum')->prefix("web-api")->group(function () {
    Route::prefix("inventory")->group(function () {
        Route::post("/", [InventoryController::class, "store"]);
        Route::get("/", [InventoryController::class, "index"]);
        Route::put("/", [InventoryController::class, "update"]);
        Route::delete("/", [InventoryController::class, "destroy"]);
        Route::post('/purchase-item', [InventoryController::class, 'purchaseItem']);
    });

    Route::prefix("users")->group(function () {
        Route::get('/get-managers-and-supervisors-only/{search_keyword}', [UsersController::class, 'getManagersAndSupervisorsOnly']);
        Route::get("/{user_title}/{search_keyword}", [
            UsersController::class,
            "getUsers",
        ]);
        Route::put("/", [UsersController::class, "update"]);
        Route::post("/change-status/{id}", [
            UsersController::class,
            "changeStatus",
        ]);
        Route::delete("/{id}", [UsersController::class, "destroy"]);
        Route::post("/add-user", [UsersController::class, "addUser"]);
    });

    Route::prefix("factory")->group(function () {
        Route::get("/", [FactoryController::class, "show"]);
        Route::post("/", [FactoryController::class, "store"]);
        Route::put("/", [FactoryController::class, "update"]);
        Route::delete("/", [FactoryController::class, "destroy"]);
    });

    Route::prefix("department")->group(function () {
        Route::get("/", [DepartmentController::class, "show"]);
        Route::post("/", [DepartmentController::class, "store"]);
        Route::put("/", [DepartmentController::class, "update"]);
        Route::delete("/", [DepartmentController::class, "destroy"]);
    });

    Route::prefix("workshop")->group(function () {
        Route::get("/", [WorkshopController::class, "show"]);
        Route::post("/", [WorkshopController::class, "store"]);
        Route::put("/", [WorkshopController::class, "update"]);
        Route::delete("/{id}", [WorkshopController::class, "destroy"]);
    });

    Route::prefix("task")->group(function () {
        Route::post("/", [TaskController::class, "addTask"]);
        Route::get("/", [TaskController::class, "show"]);
        Route::put("/", [TaskController::class, "update"]);
        Route::delete("/", [TaskController::class, "destroy"]);
        Route::post("/task-done", [TaskController::class, 'taskDone']);
    });

    Route::prefix('report-access')->group(function () {
        Route::get('/', [AccessLevelController::class, 'show']);
        Route::post('/task-access', [TaskController::class, 'taskAccess']);
    });

    Route::prefix('notifications')->group(function () {
        Route::get('/allowed-notifications', [NotificationUserController::class, 'show']);
        Route::post('/notification-access', [NotificationUserController::class, 'store']);
        Route::get('/all-notifications', [NotificationUserController::class, 'showAllNotifications']);
        Route::get('/unread-notifications', [NotificationUserController::class, 'showUnreadNotifications']);
        Route::post('/mark-as-read', [NotificationUserController::class, 'markAsRead']);
    });

    Route::prefix('report')->group(function () {
        Route::get("/income-report/{from}/{to}", [ReportController::class, 'incomeReport']);
        Route::get('/available-reports', [ReportController::class, 'getAvailableReports']);
        Route::get('/items-below-reorder-level', [ReportController::class, 'itemsBelowReorderLevel']);
        Route::get('/task-kpi', [ReportController::class, 'taskKPI']);
        Route::get('/most-used-raw-materials', [ReportController::class, 'mostUsedRawMaterials']);
        Route::get('/total-income-outgoing-of-a-order', [ReportController::class, 'getTaskIncomesAndOutgoings']);
        Route::get('/get-most-worked-employees', [ReportController::class, 'getMostWorkedEmployees']);
    });
});

Route::get("/{any}", function () {
    return view("welcome");
})->where("any", ".*");
