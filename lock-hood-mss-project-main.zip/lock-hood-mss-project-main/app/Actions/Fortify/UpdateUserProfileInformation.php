<?php

namespace App\Actions\Fortify;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\UpdatesUserProfileInformation;

class UpdateUserProfileInformation implements UpdatesUserProfileInformation
{
    /**
     * Validate and update the given user's profile information.
     *
     * @param  mixed  $user
     * @param  array  $input
     * @return void
     */
    public function update($user, array $input)
    {
        Validator::make($input, [
            "first_name" => ["required", "string", "max:255"],
            "last_name" => ["required", "string", "max:255"],
            "phone" => ["required", "string", "max:15|min:10"],
            "address1" => ["required", "string", "max:500"],
            "address2" => ["string", "max:500"],
            "joined_date" => [
                "date",
                Rule::requiredIf(fn() => $user->user_title != "Employee"),
            ],
            "email" => [
                "required",
                "string",
                "email",
                "max:255",
                Rule::unique("users")->ignore($user->id),
            ],
        ])->validateWithBag("updateProfileInformation");

        if (
            $input["email"] !== $user->email &&
            $user instanceof MustVerifyEmail
        ) {
            $this->updateVerifiedUser($user, $input);
        } else {
            $user
                ->forceFill([
                    "first_name" => $input["first_name"],
                    "last_name" => $input["last_name"],
                    "phone" => $input["phone"],
                    "address1" => $input["address1"],
                    "address2" => $input["address2"],
                    "joined_date" => $input["joined_date"],
                    "email" => $input["email"],
                ])
                ->save();
        }
    }

    /**
     * Update the given verified user's profile information.
     *
     * @param  mixed  $user
     * @param  array  $input
     * @return void
     */
    protected function updateVerifiedUser($user, array $input)
    {
        $user
            ->forceFill([
                "name" => $input["name"],
                "email" => $input["email"],
                "email_verified_at" => null,
            ])
            ->save();

        $user->sendEmailVerificationNotification();
    }
}
