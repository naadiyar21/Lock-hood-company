<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkingLine extends Model
{
    use HasFactory;

    protected $table = "working_line";

    protected $fillable = ["workshop_id", "required_space", "task_id"];

    public function task()
    {
        return $this->belongsTo(Task::class, "task_id");
    }

    public function employees()
    {
        return $this->belongsToMany(
            User::class,
            "working_employee",
            "working_line_id",
            "employee_id"
        );
    }
}
