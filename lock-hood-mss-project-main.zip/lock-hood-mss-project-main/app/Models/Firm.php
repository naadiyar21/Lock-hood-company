<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Firm extends Model
{
    use HasFactory;

    protected $table = "factory";

    protected $fillable = ["manager_id", "title"];

    public function manager()
    {
        return $this->hasOne(User::class, "id", "manager_id");
    }

    public function departments()
    {
        return $this->hasMany(Department::class, "factory_id", "id");
    }
}
