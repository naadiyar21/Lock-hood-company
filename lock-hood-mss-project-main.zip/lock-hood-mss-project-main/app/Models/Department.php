<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use HasFactory;

    protected $table = "department";

    protected $fillable = ["title", "factory_id", "manager_id"];

    public function firm()
    {
        return $this->belongsTo(Firm::class, "factory_id");
    }

    public function manager()
    {
        return $this->hasOne(User::class, "id", "manager_id");
    }

    public function workshop()
    {
        return $this->hasMany(Workshop::class, "department_id", "id");
    }
}
