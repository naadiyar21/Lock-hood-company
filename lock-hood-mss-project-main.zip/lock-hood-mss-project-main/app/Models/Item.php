<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;

    protected $table = "inventory";

    protected $fillable = [
        "item",
        "quantity",
        "stock",
        "reorder_level",
        "purchase_price",
        "unit_of_measurement",
    ];

    protected $casts = [
        'purchase_price' => 'float',
        'stock' => 'float'
    ];

    public function tasks()
    {
        return $this->belongsToMany(
            Task::class,
            "material",
            "item_id",
            "task_id"
        )->withPivot("required_amount");
    }
}
