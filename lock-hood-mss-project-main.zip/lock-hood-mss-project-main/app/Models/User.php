<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        "first_name",
        "last_name",
        "address1",
        "address2",
        "user_title",
        "joined_date",
        "phone",
        "email",
        "password",
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = ["password", "remember_token"];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        "email_verified_at" => "datetime",
    ];

    public function firm()
    {
        return $this->belongsTo(Firm::class, "id", "manager_id");
    }

    public function department()
    {
        return $this->belongsTo(Department::class, "id", "manager_id");
    }

    public function workshop()
    {
        return $this->belongsTo(Workshop::class, "id", "supervisor_id");
    }

    public function order()
    {
        return $this->hasMany(Order::class, "customer_id");
    }

    public function working_line()
    {
        return $this->belongsToMany(
            WorkingLine::class,
            "working_employee",
            "employee_id",
            "working_line_id"
        );
    }

    public function accessLevels()
    {
        return $this->hasMany(AccessLevel::class, 'user_id');
    }

    public function user_notifications()
    {
        return $this->hasMany(NotificationUser::class, 'user_id');
    }
}
