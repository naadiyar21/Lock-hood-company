<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Workshop extends Model
{
    use HasFactory;

    protected $table = "workshop";

    protected $fillable = [
        "title",
        "supervisor_id",
        "department_id",
        "total_space",
    ];

    public function department()
    {
        return $this->belongsTo(Department::class, "department_id", "id");
    }

    public function supervisor()
    {
        return $this->hasOne(User::class, "id", "supervisor_id");
    }

    public function tasks()
    {
        return $this->belongsToMany(
            Task::class,
            "working_line",
            "workshop_id",
            "task_id",
        );
    }
}
