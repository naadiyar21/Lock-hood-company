<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    protected $table = "task";

    protected $fillable = [
        "order_id",
        "title",
        "estimated_cost",
        "estimated_time",
    ];

    public function order()
    {
        return $this->hasOne(Order::class, "id", "order_id");
    }

    public function items()
    {
        return $this->belongsToMany(
            Item::class,
            "material",
            "task_id",
            "item_id"
        )->withPivot("required_amount");
    }

    public function working_line()
    {
        return $this->hasOne(WorkingLine::class, "task_id", "id");
    }

    public function workshop()
    {
        return $this->belongsToMany(
            Workshop::class,
            "working_line",
            "task_id",
            "workshop_id"
        );
    }
}
