<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkingEmployee extends Model
{
    use HasFactory;

    protected $table = "working_employee";

    protected $fillable = ["employee_id", "working_line_id"];
}
