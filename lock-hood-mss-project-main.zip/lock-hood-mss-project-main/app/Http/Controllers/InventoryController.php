<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddInventoryRequest;
use App\Http\Requests\DeleteInventoryRequest;
use App\Http\Requests\EditInventoryRequest;
use App\Models\Item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class InventoryController extends Controller
{
    public function store(AddInventoryRequest $request)
    {
        return Item::create($request->all());
    }

    public function index(Request $request)
    {
        return Item::paginate($request->per_page);
    }

    public function update(EditInventoryRequest $request)
    {
        $item = Item::find($request->id);
        return $item->update($request->all());
    }

    public function destroy(DeleteInventoryRequest $request)
    {
        return Item::destroy($request->id);
    }

    public function purchaseItem(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'purchase_quantity' => 'required'
        ]);

        $item = Item::find($request->id);
        $item->stock = $item->stock + $request->purchase_quantity;
        $item->quantity = $item->quantity + $request->purchase_quantity;

        return $item->save();
    }
}
