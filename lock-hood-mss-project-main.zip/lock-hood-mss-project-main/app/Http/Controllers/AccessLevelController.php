<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AccessLevelController extends Controller
{
    public function show(Request $request)
    {
        return User::with('accessLevels.report')->find($request->user()->id);
    }
}
