<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddUserRequest;
use App\Http\Requests\EditUserRequest;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class UsersController extends Controller
{
    public function getUsers($user_title, $search_keyword)
    {
        if ($user_title != "null") {
            if ($search_keyword != "null") {
                if ($user_title === "CXO") {
                    return User::with('working_line')->where(
                        "first_name",
                        "like",
                        "%" . $search_keyword . "%"
                    )
                        ->orWhere(
                            "last_name",
                            "like",
                            "%" . $search_keyword . "%"
                        )
                        ->where("user_title", "like", "%" . $user_title . "%")
                        ->where("user_title", "!=", "Customer")
                        ->paginate(10);
                }
                if ($search_keyword == 'all') {
                    return User::where("user_title", $user_title)
                        ->get();
                }
                return User::with('working_line')->where(
                    "first_name",
                    "like",
                    "%" . $search_keyword . "%"
                )
                    ->orWhere("last_name", "like", "%" . $search_keyword . "%")
                    ->where("user_title", "like", "%" . $user_title . "%")
                    ->paginate(10);
            } else {
                if ($user_title === "CXO") {
                    return User::with('working_line')->where(
                        "user_title",
                        "like",
                        "%" . $user_title . "%"
                    )
                        ->where("user_title", "!=", "Customer")
                        ->paginate(10);
                }
                return User::with('working_line')->where(
                    "user_title",
                    "like",
                    "%" . $user_title . "%"
                )->paginate(10);
            }
        } else {
            if ($search_keyword != "null") {
                return User::with('working_line')->where(
                    "first_name",
                    "like",
                    "%" . $search_keyword . "%"
                )
                    ->orWhere("last_name", "like", "%" . $search_keyword . "%")
                    ->paginate(10);
            } else {
                return User::with('working_line')->paginate(10);
            }
        }
    }

    public function getManagersAndSupervisorsOnly($search_keyword)
    {
        if ($search_keyword != "null") {
            return User::with(["accessLevels.report", 'user_notifications'])->where(
                "first_name",
                "like",
                "%" . $search_keyword . "%"
            )
                ->orWhere("last_name", "like", "%" . $search_keyword . "%")->where('user_title', 'Manager')->orWhere('user_title', 'Supervisor')
                ->paginate(10);
        }
        return User::with(["accessLevels.report", 'user_notifications'])->where('user_title', '=', 'Manager')->orWhere('user_title', '=', 'Supervisor')->paginate(10);
    }

    public function update(EditUserRequest $request)
    {
        $user = User::find($request->id);
       return $user->update(
           [ 'id'=>$request->id,
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'email'=>$request->email ,
            'phone'=>$request->phone ,
            'address1'=>$request->address1 ,
            'address2'=>$request->address2 ,
            'user_title'=>$request->user_title ,
            'joined_date'=>$request->joined_date ,
            'status'=>$request->status ,
            'password'=>Hash::make('password') ,
            'password_confirmation'=>Hash::make('password')]
        );
    }

    public function changeStatus($id)
    {
        $user = User::find($id);
        $user->status = !$user->status;
        return $user->update();
    }

    public function destroy($id)
    {
        $user = User::withCount(["firm", "department", "workshop"])->find($id);
        if (
            $user->firm_count < 1 &&
            $user->department_count < 1 &&
            $user->workshop_count < 1
        ) {
            return $user->delete();
        }
        return response()->json(
            [
                "errors" => [
                    [
                        "Cannot delete this user because factory or department or workshop depend on this user!",
                    ],
                ],
            ],
            409
        );
    }

    public function addUser(AddUserRequest $request)
    {
        return User::create([
            "first_name" => $request->first_name,
            "last_name" => $request->last_name,
            "email" => $request->email,
            "phone" => $request->phone,
            "address1" => $request->address1,
            "address2" => $request->address2,
            "user_title" => $request->user_title,
            "password" => Hash::make($request->password),
        ]);
    }
}
