<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddFactoryRequest;
use App\Http\Requests\DeleteFactoryRequest;
use App\Http\Requests\EditFactoryRequest;
use App\Models\Firm;
use Illuminate\Support\Facades\Log;

class FactoryController extends Controller
{
    public function show()
    {
        return Firm::with(["manager", 'departments.workshop'])->get();
    }

    public function store(AddFactoryRequest $request)
    {
        return Firm::create($request->all());
    }

    public function update(EditFactoryRequest $request)
    {
        $factory = Firm::find($request->id);
        return $factory->update($request->all());
    }

    public function destroy(DeleteFactoryRequest $request)
    {
        $factory = Firm::withCount("departments")->find($request->id);
        if ($factory->departments_count < 1) {
            return $factory->delete();
        }
        return response()->json(
            [
                "errors" => [
                    [
                        "Cannot delete factory becuase it contain(s) " .
                            $factory->departments_count .
                            " department(s)!",
                    ],
                ],
            ],
            409
        );
    }
}
