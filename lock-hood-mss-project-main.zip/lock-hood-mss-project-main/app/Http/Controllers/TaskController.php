<?php

namespace App\Http\Controllers;

use App\Events\ItemRunningOut;
use App\Http\Requests\AddTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Models\AccessLevel;
use App\Models\Item;
use App\Models\Material;
use App\Models\Order;
use App\Models\Report;
use App\Models\Task;
use App\Models\WorkingEmployee;
use App\Models\WorkingLine;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;

class TaskController extends Controller
{
    public function addTask(AddTaskRequest $request)
    {
        $order = Order::create([
            "estimated_price" => $request->margin,
            "customer_id" => $request->customer_id,
        ]);

        $currentDate = Carbon::now();
        $estimatedDate = null;

        if ($request->estimated_time_unit == "days") {
            $estimatedDate = $currentDate->addDays($request->estimated_time);
        }
        if ($request->estimated_time_unit == "weeks") {
            $estimatedDate = $currentDate->addWeeks($request->estimated_time);
        }
        if ($request->estimated_time_unit == "months") {
            $estimatedDate = $currentDate->addMonths($request->estimated_time);
        }
        if ($request->estimated_time_unit == "years") {
            $estimatedDate = $currentDate->addYears($request->estimated_time);
        }

        $task = Task::create([
            "order_id" => $order->id,
            "title" => $request->title,
            "estimated_cost" => $request->margin,
            "estimated_time" => $estimatedDate,
        ]);

        $materirals = [];

        foreach ($request->materials as $key) {
            $materiral = Material::create([
                "item_id" => $key["id"],
                "task_id" => $task->id,
                "required_amount" => $key["amount"],
            ]);
            $materirals[] = $materiral;

            $item = Item::find($key["id"]);
            $item->stock = $item->stock - $key["amount"];
            $item->save();
            if ($item->reorder_level >= $item->stock) {
                ItemRunningOut::dispatch($item);
            }
        }

        $working_line = WorkingLine::create([
            "workshop_id" => $request->workshop_id,
            "required_space" => $request->required_space,
            "task_id" => $task->id,
        ]);

        $working_employees = [];

        foreach ($request->workers_ids as $key) {
            $working_employee = WorkingEmployee::create([
                "employee_id" => $key,
                "working_line_id" => $working_line->id,
            ]);
            $working_employees[] = $working_employee;
        }

        return [$order, $task, $materirals, $working_line, $working_employees];
    }

    public function show()
    {
        return Task::with([
            "order.customer",
            "items",
            "workshop",
            "working_line.employees",
        ])->paginate(10);
    }

    public function update(UpdateTaskRequest $request)
    {
        $task = Task::find($request->id);
        if ($task == null) return response()->json(['message' => ['Task not found!']], 404);

        $currentDate = Carbon::now();
        $estimatedDate = null;

        if ($request->estimated_time_unit == "days") {
            $estimatedDate = $currentDate->addDays($request->estimated_time);
        }
        if ($request->estimated_time_unit == "weeks") {
            $estimatedDate = $currentDate->addWeeks($request->estimated_time);
        }
        if ($request->estimated_time_unit == "months") {
            $estimatedDate = $currentDate->addMonths($request->estimated_time);
        }
        if ($request->estimated_time_unit == "years") {
            $estimatedDate = $currentDate->addYears($request->estimated_time);
        }
        $task->title = $request->title;
        $task->estimated_cost = $request->margin;
        $task->estimated_time = $estimatedDate;

        $order = Order::find($task->order_id);
        if ($order == null) return response()->json(['message' => ['Task not found!']], 404);
        $order->estimated_price = $request->margin;
        $order->customer_id = $request->customer_id;

        $materials = Material::where('task_id', $request->id)->get();

        // running through each mat in db
        foreach ($materials as $key) {
            $found = false;
            $amount = -1;
            // running through each may in req
            foreach ($request->materials as $key2) {
                // mat on db === mat on req
                if ($key->item_id == $key2['id']) {
                    $found = true;
                    $amount = $key2['amount'];
                }
            }
            $item = Item::find($key->item_id);
            // if mat on db not found in mat on req than delete the item from mat on db
            if (!$found) {
                $item->stock = $item->stock + $key->required_amount;
                Material::where('task_id', $request->id)->where('item_id', $key->item_id)->delete();
            } else {
                if ($key->required_amount > $amount) $item->stock = $item->stock + ($key->required_amount - $amount);
                else $item->stock = $item->stock - ($amount - $key->required_amount);
                Material::where('task_id', $request->id)->where('item_id', $key->item_id)->update([
                    'required_amount' => $amount
                ]);
            }
            $item->save();
            if ($item->reorder_level >= $item->stock) {
                ItemRunningOut::dispatch($item);
            }
        }

        if (count($materials) < count($request->materials)) {
            $tableIds = DB::table('material')->where('task_id', $request->id)->pluck('item_id')->toArray();
            $ids = array_column($request->materials, 'id');
            $missingIds = array_diff($ids, $tableIds);

            foreach ($request->materials as $key) {
                if (in_array($key['id'], $missingIds)) {
                    $item = Item::find($key['id']);
                    $item->stock = $item->stock - $key['amount'];
                    $item->save();

                    Material::create([
                        "item_id" => $key["id"],
                        "task_id" => $request->id,
                        "required_amount" => $key["amount"],
                    ]);
                }
            }
        }


        $working_line = WorkingLine::where('task_id', $request->id)->first();
        if ($working_line == null) return response()->json(['message' => ['Working line not found!']], 404);
        $working_line->workshop_id = $request->workshop_id;
        $working_line->required_space = $request->required_space;

        WorkingEmployee::where('working_line_id', $working_line->id)->delete();
        foreach ($request->workers_ids as $key) {
            WorkingEmployee::create([
                "employee_id" => $key,
                "working_line_id" => $working_line->id
            ]);
        }

        $task->save();
        $order->save();
        $working_line->save();

        return response('done', 200);
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'id' => ['required', Rule::exists('task', 'id')]
        ]);

        Material::where('task_id', $request->id)->delete();
        $working_line = WorkingLine::where('task_id', $request->id)->first();
        $working_line->delete();
        WorkingEmployee::where('working_line_id', $working_line->id)->delete();
        Task::find($request->id)->delete();

        return response('', 200);
    }

    public function taskDone(Request $request)
    {
        $request->validate([
            'taskId' => ['required', Rule::exists('task', 'id')]
        ]);

        Material::where('task_id', $request->taskId)->update([
            'is_done' => true
        ]);
        $working_line = WorkingLine::where('task_id', $request->taskId)->first();
        WorkingEmployee::where('working_line_id', $working_line->id)->update([
            'is_done' => true
        ]);
        WorkingLine::where('task_id', $request->taskId)->update([
            'is_done' => true
        ]);
        Task::where('id', $request->taskId)->update([
            'is_done' => true
        ]);

        return response('', 200);
    }

    public function taskAccess(Request $request)
    {
        $request->validate([
            'user_id' => ['required', Rule::exists('users', 'id')],
            'has_access' => ['required', 'boolean'],
            'which_access' => ['required']
        ]);

        $report = Report::where('title', $request->which_access)->first();
        if ($report == null) {
            $report = Report::create([
                'title' => $request->which_access,
                'description' => 'Task Add, Edit and Delete'
            ]);
        }

        $access_level = AccessLevel::where('user_id', $request->user_id)->where('report_id', $report->id)->first();
        if ($access_level == null) {
            return AccessLevel::create([
                'user_id' => $request->user_id,
                'report_id' => $report->id,
                'has_access' => $request->has_access
            ]);
        }
        $access_level->has_access = $request->has_access;
        return $access_level->save();
    }
}
