<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddWorkshopRequest;
use App\Http\Requests\DeleteWorkshopRequest;
use App\Http\Requests\EditWorkshopRequest;
use App\Models\Workshop;

class WorkshopController extends Controller
{
    public function show()
    {
        return Workshop::with(["department.firm", "supervisor", 'tasks.working_line'])->get();
    }

    public function store(AddWorkshopRequest $request)
    {
        return Workshop::create($request->all());
    }

    public function update(EditWorkshopRequest $request)
    {
        $workshop = Workshop::find($request->id);
        return $workshop->update($request->all());
    }

    public function destroy($id)
    {
        // $workshop = Workshop::withCount(["department", "supervisor"])->find($id);
        // if ($workshop->department_count < 1 && $workshop->supervisor_count) {
        //     return $workshop->delete();
        // }
        // return response()->json(['errors' => [['Cannot delete workshop becuase it depends on a supervisor!']]], 409);
        return Workshop::destroy($id);
    }
}
