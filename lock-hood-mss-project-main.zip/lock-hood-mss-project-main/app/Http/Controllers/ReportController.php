<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Material;
use App\Models\Report;
use App\Models\Task;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ReportController extends Controller
{
    public function incomeReport($from, $to)
    {
        $report = [
            'from' => null,
            'to' => null,
            'total_orders' => 0,
            'total_material_cost' => 0,
            'revenues' => 0,
            'orders' => []
        ];

        $completedTasks = null;

        $selectCompletedTasksQuery = "";

        if ($from == 'null' || $to == 'null') {
            $selectCompletedTasksQuery = "SELECT * FROM task WHERE is_done = 1";
            $completedTasks = DB::select($selectCompletedTasksQuery);
            foreach ($completedTasks as $index => $task) {
                $getItemsRelatedToTaskQuery = "SELECT inventory.*, material.task_id AS pivot_task_id, material.item_id AS pivot_item_id, material.required_amount AS pivot_required_amount FROM inventory INNER JOIN material ON inventory.id = material.item_id WHERE material.task_id = " . $completedTasks[$index]->id;
                $getOrderRelatedToTaskQuery = "SELECT * FROM `order` WHERE `order`.`id` = " . $completedTasks[$index]->id;
                $completedTasks[$index] = get_object_vars($task);
                $completedTasks[$index]['items'] = DB::select($getItemsRelatedToTaskQuery);
                $completedTasks[$index]['order'] = DB::select($getOrderRelatedToTaskQuery);
            }
        } else {
            $selectCompletedTasksQuery = "SELECT * FROM task WHERE is_done = 1 AND created_at BETWEEN '$from' AND '$to'";
            $completedTasks = DB::select($selectCompletedTasksQuery);
            foreach ($completedTasks as $index => $task) {
                $getItemsRelatedToTaskQuery = "SELECT inventory.*, material.task_id AS pivot_task_id, material.item_id AS pivot_item_id, material.required_amount AS pivot_required_amount FROM inventory INNER JOIN material ON inventory.id = material.item_id WHERE material.task_id = " . $completedTasks[$index]->id;
                $getOrderRelatedToTaskQuery = "SELECT * FROM `order` WHERE `order`.`id` = " . $completedTasks[$index]->id;
                $completedTasks[$index] = get_object_vars($task);
                $completedTasks[$index]['items'] = DB::select($getItemsRelatedToTaskQuery);
                $completedTasks[$index]['order'] = DB::select($getOrderRelatedToTaskQuery);
            }
        }


        if ($completedTasks != null) {
            foreach ($completedTasks as $key => $task) {
                $report['revenues'] = $report['revenues'] + $task['order'][0]->estimated_price;
                $report['total_orders'] = $report['total_orders'] + 1;
                $total_material_cost = 0;
                foreach ($task['items'] as $item) {
                    $item = get_object_vars($item);
                    $total_material_cost = ($item['purchase_price'] * $item['pivot_required_amount']);
                    $report['total_material_cost'] =  $report['total_material_cost'] + $total_material_cost;
                }
                $report['orders'][] = get_object_vars($task['order'][0]);
                $report['orders'][$key]['total_material_cost'] = $total_material_cost;
            }
        }


        return response($report, 200);
    }

    public function getAvailableReports()
    {
        return Report::all();
    }

    public function itemsBelowReorderLevel()
    {
        $query = "SELECT * FROM inventory WHERE reorder_level > stock";
        $result = DB::select($query);

        return response($result, 200);
    }

    public function taskKPI()
    {
        $getTasksQuery = "SELECT * FROM task WHERE is_done = 1";
        $completedTasks = DB::select($getTasksQuery);
        foreach ($completedTasks as $index => $task) {
            $created = Carbon::parse($task->created_at);
            $finished = Carbon::parse($task->updated_at);
            $estimated_time = Carbon::parse($task->estimated_time);

            $consumed_time = $finished->diffInHours($created);
            $total_given_time = $estimated_time->diffInHours($created);

            $getWorkingLineOfTheTaskQuery = "SELECT * FROM working_line WHERE task_id = " . $task->id;
            $workingLine = get_object_vars(DB::select($getWorkingLineOfTheTaskQuery)[0]);
            $getWorkingEmployeesOfTheTaskQuery  = "SELECT * FROM working_employee WHERE working_line_id = " . $workingLine['id'];
            $workingEmployees = DB::select($getWorkingEmployeesOfTheTaskQuery);
            $employees = [];
            foreach ($workingEmployees as $key => $value) {
                $value = get_object_vars($value);
                $employee = DB::select("SELECT * FROM users WHERE id = " . $value['employee_id']);
                $employee = get_object_vars($employee[0]);
                $employees[] = $employee;
            }
            $getWorkshopQuery = "SELECT * FROM workshop WHERE id = " . $workingLine['workshop_id'];
            $workshop = get_object_vars(DB::select($getWorkshopQuery)[0]);
            $getWorkshopSupervisorQuery = "SELECT * FROM users WHERE id = " . $workshop['supervisor_id'];
            $workshopSupervisor = DB::select($getWorkshopSupervisorQuery);

            $completedTasks[$index] = get_object_vars($task);
            $completedTasks[$index]['employees'] = $employees;
            $completedTasks[$index]['supervisor'] = get_object_vars($workshopSupervisor[0]);
            $completedTasks[$index]['total_give_time_in_hours'] = $total_given_time;
            $completedTasks[$index]['consumed_time_in_hours'] = $consumed_time;
            $completedTasks[$index]['KPI'] = ($consumed_time / $total_given_time) * 100;
        }

        return $completedTasks;
    }

    function mostUsedRawMaterials()
    {
        $getCompletedTasks = "SELECT * FROM task WHERE is_done = 1";
        $completedTasks = DB::select($getCompletedTasks);
        $completedTasksIDs = array_column($completedTasks, 'id');

        // $getCompletedTasksRawMaterialsQuery = "SELECT `inventory`.*, `material`.`task_id` AS `pivot_task_id`, `material`.`item_id` AS `pivot_item_id`, `material`.`required_amount` AS `pivot_required_amount` FROM `inventory` INNER JOIN `material` ON `inventory`.`id` = `material`.`item_id` WHERE `material`.`task_id` IN (" . implode(", ", $completedTasksIDs) . ") ORDER BY pivot_required_amount DESC";
        $getCompletedTasksRawMaterialsQuery = "SELECT i.id AS item_id, i.item AS item_name, SUM(m.required_amount) AS total_required_amount,i.unit_of_measurement as unit, COUNT(*) AS num_tasks FROM material m JOIN inventory i ON m.item_id = i.id GROUP BY i.id, i.item,i.unit_of_measurement ORDER BY num_tasks DESC;";
        $completedTasksRawMaterials = DB::select($getCompletedTasksRawMaterialsQuery);

        return $completedTasksRawMaterials;
    }

    function getTaskIncomesAndOutgoings()
    {
        $getCompletedTasks = "SELECT * FROM task WHERE is_done = 1";
        $completedTasks = DB::select($getCompletedTasks);

        foreach ($completedTasks as $key => $value) {
            $task_id = $value->id;
            $getCompletedTasksRawMaterialsQuery = "SELECT `inventory`.*, `material`.`task_id` AS `pivot_task_id`, `material`.`item_id` AS `pivot_item_id`, `material`.`required_amount` AS `pivot_required_amount` FROM `inventory` INNER JOIN `material` ON `inventory`.`id` = `material`.`item_id` WHERE `material`.`task_id` = $task_id";
            $completedTasksRawMaterials = DB::select($getCompletedTasksRawMaterialsQuery);
            $total_outgoing = 0;
            foreach ($completedTasksRawMaterials as $key1 => $value1) {
                $total_outgoing = $total_outgoing + ($value1->pivot_required_amount * $value1->purchase_price);
            }
            $completedTasks[$key] = get_object_vars($value);
            $completedTasks[$key]['total_outgoing'] = $total_outgoing;
        }

        return $completedTasks;
    }

    function getMostWorkedEmployees()
    {
        $query = "SELECT u.first_name, u.last_name, u.joined_date, COUNT(*) as num_tasks FROM users u JOIN working_employee we ON we.employee_id = u.id JOIN working_line wl ON wl.id = we.working_line_id JOIN task t ON t.id = wl.task_id WHERE t.is_done = true GROUP BY u.first_name, u.last_name, u.joined_date ORDER BY num_tasks DESC;";
        $employees = DB::select($query);

        return $employees;
    }
}
