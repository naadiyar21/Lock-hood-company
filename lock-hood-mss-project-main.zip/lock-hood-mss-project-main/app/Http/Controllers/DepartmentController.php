<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddDepartmentRequest;
use App\Http\Requests\DeleteDepartmentRequest;
use App\Http\Requests\EditDepartmentRequest;
use App\Models\Department;

class DepartmentController extends Controller
{
    public function show()
    {
        return Department::with(["firm", "manager", "workshop"])->get();
    }

    public function store(AddDepartmentRequest $request)
    {
        return Department::create($request->all());
    }

    public function update(EditDepartmentRequest $request)
    {
        $department = Department::find($request->id);
        return $department->update($request->all());
    }

    public function destroy(DeleteDepartmentRequest $request)
    {
        $department = Department::withCount("workshop")->find($request->id);
        if ($department->workshop_count < 1) {
            return $department->delete();
        }
        return response()->json(
            [
                "errors" => [
                    [
                        "Cannot delete department becuase it contain(s) " .
                            $department->workshop_count .
                            " workshop(s)!",
                    ],
                ],
            ],
            409
        );
    }
}
