<?php

namespace App\Http\Controllers;

use App\Models\NotificationUser;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class NotificationUserController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => ['required'],
            'which_notification' => ['required'],
            'notify_or_not' => ['required', 'boolean']
        ]);

        $notificationUser = NotificationUser::where('user_id', $request->user_id)->where('which_notification', $request->which_notification)->first();
        if ($notificationUser != null) {
            return NotificationUser::where('user_id', $request->user_id)->where('which_notification', $request->which_notification)->update([
                'notify_or_not' => $request->notify_or_not
            ]);
        }

        return NotificationUser::create([
            'user_id' => $request->user_id,
            'which_notification' => $request->which_notification,
            'notify_or_not' => $request->notify_or_not
        ]);
    }

    public function show(Request $request)
    {
        return User::with('user_notifications')->find($request->user()->id);
    }

    public function showAllNotifications()
    {
        return auth()->user()->notifications;
    }

    public function showUnreadNotifications()
    {
        return auth()->user()->unreadNotifications;
    }

    public function markAsRead(Request $request)
    {
        if ($request->id != null) {
            foreach (auth()->user()->unreadNotifications as $notification) {
                if ($notification->id === $request->id) {
                    return $notification->markAsRead();
                }
            }
        } else {
            return auth()->user()->unreadNotifications->markAsRead();
        }
    }
}
