<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class EditInventoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            "id" => ["required", Rule::exists("inventory", "id")],
            "item" => "required|string",
            "quantity" => "required|numeric",
            "stock" => "required|numeric",
            "reorder_level" => "numeric",
            "purchase_price" => "required|numeric",
            "unit_of_measurement" => [
                "required",
                Rule::in(["kg", "g", "m", "cm", "l", "ml"]),
            ],
        ];
    }
}
