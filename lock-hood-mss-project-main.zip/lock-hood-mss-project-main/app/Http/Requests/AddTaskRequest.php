<?php

namespace App\Http\Requests;

use App\Rules\AvailableMaterials;
use App\Rules\AvailableRequiredSpace;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AddTaskRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            "customer_id" => ["required", Rule::exists("users", "id")],
            "title" => ["required", "string"],
            "workshop_id" => ["required", Rule::exists("workshop", "id")],
            "required_space" => [
                "required",
                new AvailableRequiredSpace($this->workshop_id),
            ],
            "workers_ids" => ["required"],
            "materials" => ["required", new AvailableMaterials()],
            "margin" => ["required", "numeric"],
            "estimated_time" => ["required", "numeric"],
            "estimated_time_unit" => [
                "required",
                Rule::in(["days", "weeks", "months", "years"]),
            ],
        ];
    }
}
