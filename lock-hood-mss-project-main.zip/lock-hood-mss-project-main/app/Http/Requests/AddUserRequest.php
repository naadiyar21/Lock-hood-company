<?php

namespace App\Http\Requests;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AddUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            "first_name" => ["required", "string", "max:255"],
            "last_name" => ["required", "string", "max:255"],
            "phone" => ["required", "string", "max:15|min:10"],
            "address1" => ["required", "string", "max:500"],
            "address2" => ["string", "max:500"],
            "joined_date" => [
                Rule::requiredIf(fn() => $this->user_title != "Customer"),
            ],
            "user_title" => [
                "required",
                Rule::in(["Manager", "Supervisor", "Customer", "Employee"]),
            ],
            "email" => [
                "required",
                "string",
                "email",
                "max:255",
                Rule::unique(User::class),
            ],
            "password" => [
                Rule::requiredIf(
                    fn() => $this->user_title == "Supervisor" ||
                        $this->user_title == "Manager"
                ),
                "confirmed",
            ],
        ];
    }
}
