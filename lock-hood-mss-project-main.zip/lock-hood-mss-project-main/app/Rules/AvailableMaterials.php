<?php

namespace App\Rules;

use App\Models\Item;
use App\Models\Material;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\Log;

class AvailableMaterials implements Rule
{
    protected $shortageItem = null;
    protected $requestedAmount = 0;
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        foreach ($value as $key) {
            $item = Item::find($key["id"]);
            if ($item->stock < $key["amount"]) {
                $this->shortageItem = $item;
                return false;
            }
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return "There are only " .
            $this->shortageItem["stock"] .
            " " .
            $this->shortageItem["unit_of_measurement"] .
            " of " .
            " " .
            $this->shortageItem["item"] .
            " Avaiable!";
    }
}
