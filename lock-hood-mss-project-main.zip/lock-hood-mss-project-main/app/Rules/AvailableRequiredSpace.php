<?php

namespace App\Rules;

use App\Models\WorkingLine;
use App\Models\Workshop;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\Log;

class AvailableRequiredSpace implements Rule
{
    protected $workshopId;
    protected $free;
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct($wid)
    {
        $this->workshopId = $wid;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $workshop = Workshop::find($this->workshopId);
        $working_lines = WorkingLine::where(
            "workshop_id",
            "=",
            $this->workshopId
        )->where('is_done', true)->get();
        $total_occupied = 0;
        foreach ($working_lines as $wl) {
            if ($wl["required_space"]) {
                $total_occupied += $value;
            }
        }
        $this->free = $workshop->total_space - $total_occupied;
        return $this->free >= $value;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return "There is only " . $this->free . " free spaces on this workhop";
    }
}
