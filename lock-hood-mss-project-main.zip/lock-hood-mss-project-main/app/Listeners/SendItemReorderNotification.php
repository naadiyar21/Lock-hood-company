<?php

namespace App\Listeners;

use App\Models\User;
use App\Notifications\ItemReorderNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

class SendItemReorderNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle($event)
    {
        $item = $event->item;

        $users =  User::whereHas('user_notifications', function ($query) {
            $query->where('notify_or_not', true);
        })->get();

        Notification::Send($users, new ItemReorderNotification($item));
    }
}
