<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Department;
use App\Models\Firm;
use App\Models\Report;
use App\Models\Workshop;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(1)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        $this->call(UsersSeeder::class);
        $this->call(ItemSeeder::class);
        Firm::factory()
            ->times(3)
            ->create();
        Department::factory()
            ->times(9)
            ->create();
        Workshop::factory()
            ->times(9)
            ->create();

        Report::create([
            'title' => 'INCOME_REPORT',
            'description' => 'Income Report'
        ]);

        Report::create([
            'title' => 'ITEMS_BELOW_REORDER_LEVEL_REPORT',
            'description' => 'Items Below Reorder Level Report.'
        ]);

        Report::create([
            'title' => 'TASK_KPI_REPORT',
            'description' => 'KPI of the people who involved in a task.'
        ]);

        Report::create([
            'title' => 'MOST_USED_MATERIALS_REPORT',
            'description' => 'Frequently Used Raw Materials on Tasks.'
        ]);

        Report::create([
            'title' => 'TASK_INCOME_OUTGOING_REPORT',
            'description' => 'How much we earn on a order and how much we spent on a order.'
        ]);

        Report::create([
            'title' => 'MOST_INVOLVED_EMPLOYEES_REPORT',
            'description' => 'Employees with most involvement in tasks.'
        ]);
    }
}
