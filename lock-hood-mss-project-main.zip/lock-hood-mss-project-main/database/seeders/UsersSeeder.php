<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::factory()->create([
            "user_title" => "admin",
            "email" => "admin@lockhood.com",
        ]); // 1
        User::factory()->create(["user_title" => "CEO"]); // 2
        User::factory()->create(["user_title" => "CSO"]); //3
        User::factory()->create(["user_title" => "CR&DO"]); // 4
        User::factory()->create(["user_title" => "CPO"]); //5
        User::factory()->create(["user_title" => "CFO"]); //6
        User::factory()->create(["user_title" => "CIO"]); //7
        User::factory()->create(["user_title" => "CDE"]); //8
        User::factory()->create(["user_title" => "CHRO"]); //9
        User::factory()->create(["user_title" => "CE"]); //10
        User::factory()
            ->times(12)
            ->create(["user_title" => "Manager"]); // 11 - 22
        User::factory()
            ->times(9)
            ->create(["user_title" => "Supervisor"]); // 23 - 31
        User::factory()
            ->times(150)
            ->create(["user_title" => "Employee"]); // 32 - 181
    }
}
