<?php

namespace Database\Factories;

use App\Models\Workshop;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Workshop>
 */
class WorkshopFactory extends Factory
{
    protected $model = Workshop::class;
    private static $supervisor_id = 23;
    private static $department_id = 1;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            "supervisor_id" => self::$supervisor_id++,
            "department_id" => self::$department_id++,
            "title" => $this->faker->text(20),
            "total_space" => 12,
        ];
    }
}
