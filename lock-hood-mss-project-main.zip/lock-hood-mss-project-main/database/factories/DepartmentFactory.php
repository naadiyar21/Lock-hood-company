<?php

namespace Database\Factories;

use App\Models\Department;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Department>
 */
class DepartmentFactory extends Factory
{
    protected $model = Department::class;
    private static $manager_id = 14;
    private static $factory_id = 1;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        if (self::$factory_id == 4) {
            self::$factory_id = 1;
        }
        return [
            "manager_id" => self::$manager_id++,
            "factory_id" => self::$factory_id++,
            "title" => $this->faker->text(25),
        ];
    }
}
