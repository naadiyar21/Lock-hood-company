<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Item>
 */
class ItemFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $qty = rand(1, 1000);
        $stock = rand(1, $qty);
        $reorder_level = floor((10 / 100) * $qty);
        return [
            "item" => $this->faker->text(20),
            "quantity" => $qty,
            "stock" => $stock,
            "reorder_level" => $reorder_level,
            "purchase_price" => rand(10, 10000),
            "unit_of_measurement" => $this->faker->randomElement([
                "kg",
                "g",
                "m",
                "cm",
                "l",
                "ml",
            ]),
        ];
    }
}
