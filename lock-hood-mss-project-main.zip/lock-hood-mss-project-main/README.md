# Lock Hood Management System

## Required software installation

<br>

1. Download and install XAMPP. (with this link https://www.apachefriends.org/download.html for your desired OS) Make sure to download version "8.1.12 / PHP 8.1.12".
2. Download and install Composer via https://getcomposer.org/Composer-Setup.exe
3. Download and install latest Node-js via https://nodejs.org/dist/v18.12.1/node-v18.12.1-x64.msi
4. Download and install Git version controll via https://github.com/git-for-windows/git/releases/download/v2.39.0.windows.1/Git-2.39.0-64-bit.exe
5. Download an install VS Code via https://code.visualstudio.com/download

after successfully installing above mentioned softwares. you have to clone this repo. if you don't know how to clone a repo than make sure to watch some tutorials on youtube. (search 'how to clone github repository').

<br>

after cloning repo open the cloned project in VS Code and open the terminal window on the VS Code. (to open the terminal window on the VS Code Goto Terminal menu on top and click New Terminal or just enter the shorcut `Ctrl+Shipt+` `).

<br>

in the terminal window inside the VS Code type

```
npm i
```

to install all the npm packages.
after that type

```
composer install
```

<br>

right now all the necessary packages are installed to run/preview this project. now, make sure you run MySQL and Apache service by open the xampp control panel in your machine and click start button for MySQL and Apache.

![](https://phpandmysql.com/extras/installing-xampp/screenshots/starting-xampp.png "Open Xampp Control panel")

![](https://devtuts.butlerccwebdev.net/testserver/xampp-control-panel.png "Xampp Control Panel")

<br>

## Creating new lock_hood MySQL database

<br>
after running the MYSQL and Apache service on the xampp control panel. open any web browser and goto 
<br>
<a href="http://localhost/phpmyadmin/index.php?route=/server/databases">http://localhost/phpmyadmin/index.php?route=/server/databases</a>
<br>
and create a new database named lock_hood like below image showing

![](https://www.studentstutorial.com/img/phpmyadmin2.PNG)

<br>

after creating new database go back to VS Code and create new file named .env and copy all the content from .env.example to newly created .env file. (if you setup a password for the mysql server than enter that password inside the .env file right after `DB_PASSWORD=`)

after .env file and copy pasting the content go back to terminal window in the VS Code and type

```
php artisan migrate:fresh --seed
```

after completing the above command type

```
npm run dev
```

and open another terminal window inside the VS Code just like above mentioned.
and type

```
php artisan serve
```

to preview this project in the browser
and you will get link like `http://127.0.0.1:8000` in the second terminal paste this in the browser and you will preview this project.

<br>

admin account email :- admin@lockhood.com
<br>
admin account password :- password
