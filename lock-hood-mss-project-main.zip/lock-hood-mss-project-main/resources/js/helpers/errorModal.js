const { useGlobalStore } = require("@/stores/globalStore");

const globalStore = useGlobalStore();
