export function getPage(url) {
    let page = 1;
    if (url) {
        page = url.split("?")[1].split("=")[1];
    }
    return page;
}
