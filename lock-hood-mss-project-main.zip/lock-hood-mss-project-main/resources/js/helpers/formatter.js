export function getServerValidationErrors(erros) {
    const errors = {};
    if (!erros) return errors;
    Object.keys(erros).forEach((key) => {
        errors[key] = erros[key][0];
    });
    return errors;
}

export function getErrorsForNotification(error) {
    let status = error.status;
    let title = "Error";
    let text = [];

    let data = error.data;

    if (error.statusText) title = error.statusText;
    else if (data.message) title = data.message;

    if (data.errors && Object.values(data.errors).length > 0) {
        text = Object.values(data.errors).map((x) => x[0]);
    }

    if (!text.length && data.message) {
        text.push(data.message);
    }

    return { title, text, status };
}
