<template>
    <div class="container-fluid mt-4">
        <ModalComponent
            ref="incomeReportModalRef"
            :modal-id="'incomeReportModal'"
            :title="'Income Report'"
        >
            <template #body>
                <h4 class="text-center">Lock Hood</h4>
                <h5
                    v-if="report.dates.from != null && report.dates.to != null"
                    class="text-center"
                >
                    Income Report From
                    {{ new Date(report.dates.from).toLocaleDateString() }} to
                    {{ new Date(report.dates.to).toLocaleDateString() }}
                </h5>
                <h5 v-else class="text-center">Income Report</h5>
                <hr />
                <div class="d-flex justify-content-evenly">
                    <div>
                        <p class="mb-4">Total Orders</p>
                        <p class="mb-4">Net Income</p>
                        <p class="mb-4">Total Material Cost</p>
                        <p class="mb-4">Total Revenue</p>
                    </div>
                    <div>
                        <p class="mb-4">
                            {{ report.incomeReport.value?.total_orders }}
                        </p>
                        <p class="mb-4">
                            $
                            {{
                                (
                                    +report.incomeReport.value
                                        ?.total_material_cost +
                                    +report.incomeReport.value?.revenues
                                )?.toFixed(2)
                            }}
                        </p>
                        <p class="mb-4">
                            $
                            {{
                                report.incomeReport.value?.total_material_cost?.toFixed(
                                    2
                                )
                            }}
                        </p>
                        <p class="mb-4">
                            $
                            {{
                                report.incomeReport.value?.revenues?.toFixed(2)
                            }}
                        </p>
                    </div>
                </div>
                <hr />
                <div style="max-height: 250px; padding: 10px">
                    <Line v-if="data != null" :data="data" :options="options" />
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="ItemsBelowReorderLevelReportModalRef"
            :modal-id="'ItemsBelowReorderLevelReportModal'"
            :title="'Items Below Reorder Level Report'"
        >
            <template #body>
                <h4 class="text-center">Lock Hood</h4>
                <h5 class="text-center">Items Below Reorder Level Report</h5>
                <hr />
                <div class="table-responsive mb-4" style="max-height: 300px">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Item</th>
                                <th scope="col">Total Quantity</th>
                                <th scope="col">Crurrent Stock</th>
                                <th scope="col">Reorder Level</th>
                                <th scope="col">Purchase Price</th>
                                <th scope="col">Unit of Measurement</th>
                            </tr>
                        </thead>
                        <tbody
                            v-if="
                                report.itemsBelowReorderLevel?.value?.length > 0
                            "
                        >
                            <tr
                                v-for="i in report?.itemsBelowReorderLevel
                                    ?.value"
                                :key="i?.id"
                            >
                                <td>{{ i?.id }}</td>
                                <td>{{ i?.item }}</td>
                                <td>{{ i?.quantity }}</td>
                                <td>
                                    <strong>{{ i?.stock }}</strong>
                                </td>
                                <td>
                                    <strong>{{ i?.reorder_level }}</strong>
                                </td>
                                <td>{{ i?.purchase_price }}</td>
                                <td>{{ i?.unit_of_measurement }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <hr />
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="TaskKPIModalRef"
            :modal-id="'TaskKPIModal'"
            :title="'KPI Report of Workers/Supervisors Involved in a Task'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <h4 class="text-center">Lock Hood</h4>
                <h5 class="text-center">
                    KPI Report of Workers/Supervisors Involved in a Task
                </h5>
                <hr />
                <div class="table-responsive mb-4" style="max-height: 300px">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Task Title</th>
                                <th scope="col">Estimated Time (in Hours)</th>
                                <th scope="col">Consumed Time (in Hours)</th>
                                <th scope="col">Worked Employees</th>
                                <th scope="col">Supervisor of the Task</th>
                            </tr>
                        </thead>
                        <tbody v-if="report?.taskKPIs?.value?.length > 0">
                            <tr
                                v-for="kpi in report?.taskKPIs?.value"
                                :key="kpi.id"
                            >
                                <td>{{ kpi?.id }}</td>
                                <td>{{ kpi?.title }}</td>
                                <td>{{ kpi?.total_give_time_in_hours }}</td>
                                <td>{{ kpi?.consumed_time_in_hours }}</td>
                                <td>
                                    <p v-for="e in kpi?.employees" :key="e.id">
                                        {{ e.first_name }} {{ e.last_name }}
                                    </p>
                                </td>
                                <td>
                                    {{ kpi?.supervisor?.first_name }}
                                    {{ kpi?.supervisor?.last_name }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <hr />
                <div style="max-height: 250px; padding: 10px">
                    <Bar v-if="data != null" :data="data" :options="options" />
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="FrequentlyUsedRawMaterialRef"
            :modal-id="'FrequentlyUsedRawMaterial'"
            :title="'Frequently Used Raw Material in Tasks'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <h4 class="text-center">Lock Hood</h4>
                <h5 class="text-center">
                    Frequently Used Raw Material in Tasks Report
                </h5>
                <hr />
                <div class="table-responsive mb-4" style="max-height: 300px">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Material ID</th>
                                <th scope="col">Material Name</th>
                                <th scope="col">Material Used Total Tasks</th>
                                <th scope="col">Total Used Amount</th>
                            </tr>
                        </thead>
                        <tbody
                            v-if="report?.materialUsedInTask?.value?.length > 0"
                        >
                            <tr
                                v-for="material in report?.materialUsedInTask
                                    ?.value"
                                :key="material.item_id"
                            >
                                <td>{{ material?.item_id }}</td>
                                <td>{{ material?.item_name }}</td>
                                <td>{{ material?.num_tasks }}</td>
                                <td>
                                    {{ material?.total_required_amount }}
                                    {{ material?.unit }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <hr />
                <div style="max-height: 250px; padding: 10px">
                    <Bar v-if="data != null" :data="data" :options="options" />
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="totalIncomeAndOutgoingModalRef"
            :modal-id="'totalIncomeAndOutgoingModal'"
            :title="'Total Income and Outgoing of a order'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <h4 class="text-center">Lock Hood</h4>
                <h5 class="text-center">
                    Total Income and Outgoing of a order Report
                </h5>
                <hr />
                <div class="table-responsive mb-4" style="max-height: 300px">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Order ID</th>
                                <th scope="col">Task Name</th>
                                <th scope="col">Total Margin</th>
                                <th scope="col">Total Material Cost</th>
                            </tr>
                        </thead>
                        <tbody
                            v-if="
                                report?.totalIncomeAndOutgoingOfAOrder?.value
                                    ?.length > 0
                            "
                        >
                            <tr
                                v-for="i in report
                                    ?.totalIncomeAndOutgoingOfAOrder?.value"
                                :key="i.id"
                            >
                                <td>{{ i?.order_id }}</td>
                                <td>{{ i?.title }}</td>
                                <td>{{ i?.estimated_cost?.toFixed(2) }}</td>
                                <td>{{ i?.total_outgoing?.toFixed(2) }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <hr />
                <div style="max-height: 250px; padding: 10px">
                    <Bar v-if="data != null" :data="data" :options="options" />
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="mostWorkedEmployeesModalRef"
            :modal-id="'mostWorkedEmployeesModal'"
            :title="'Employees With Most Task Involvement'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <h4 class="text-center">Lock Hood</h4>
                <h5 class="text-center">
                    Employees With Most Task Involvement Report
                </h5>
                <hr />
                <div class="table-responsive mb-4" style="max-height: 300px">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">First Name</th>
                                <th scope="col">Last Name</th>
                                <th scope="col">Joined Date</th>
                                <th scope="col">Total Tasks Involved</th>
                            </tr>
                        </thead>
                        <tbody
                            v-if="
                                report?.mostWorkedEmployees?.value?.length > 0
                            "
                        >
                            <tr
                                v-for="(i, index) in report?.mostWorkedEmployees
                                    ?.value"
                                :key="index"
                            >
                                <td>{{ i?.first_name }}</td>
                                <td>{{ i?.last_name }}</td>
                                <td>{{ i?.joined_date }}</td>
                                <td>{{ i?.num_tasks }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <h5>Select the date range of reports</h5>
        <div class="row mb-4">
            <div class="col-6">
                <label class="form-label">From</label>
                <input
                    v-model="report.dates.from"
                    type="date"
                    class="form-control"
                />
            </div>
            <div class="col-6">
                <label class="form-label">To</label>
                <input
                    v-model="report.dates.to"
                    type="date"
                    class="form-control"
                />
            </div>
        </div>
        <hr />

        <div class="row my-4 gap-4 justify-content-center">
            <div
                v-if="hasAccess('INCOME_REPORT')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <a
                    class="text-decoration-none"
                    href=""
                    @click.prevent="
                        () => {
                            report.getIncomeReport().then(() => {
                                incomeReportModalRef.show();
                                loadIncomeReportData();
                            });
                        }
                    "
                >
                    <img
                        :src="IncomeImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Income Report</h4>
                    </div>
                </a>
            </div>
            <div
                v-if="hasAccess('ITEMS_BELOW_REORDER_LEVEL_REPORT')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <a
                    class="text-decoration-none"
                    href=""
                    @click.prevent="
                        () => {
                            report.getItemsBelowReorderLevel().then(() => {
                                ItemsBelowReorderLevelReportModalRef.show();
                            });
                        }
                    "
                >
                    <img
                        :src="ItemsBelowReorderLevelImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">
                            Items Below Reorder Level
                        </h4>
                    </div>
                </a>
            </div>
            <div
                v-if="hasAccess('TASK_KPI_REPORT')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <a
                    class="text-decoration-none"
                    href=""
                    @click.prevent="
                        () => {
                            report.getTaskKPIs().then(() => {
                                TaskKPIModalRef.show();
                                loadTaskKPIReportData();
                            });
                        }
                    "
                >
                    <img
                        :src="TaskKPIImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Task KPI</h4>
                    </div>
                </a>
            </div>
            <div
                v-if="hasAccess('MOST_USED_MATERIALS_REPORT')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <a
                    class="text-decoration-none"
                    href=""
                    @click.prevent="
                        () => {
                            report.getMaterialsUsedInTask().then(() => {
                                FrequentlyUsedRawMaterialRef.show();
                                loadFrequentlyUsedRawMaterialData();
                            });
                        }
                    "
                >
                    <img
                        :src="MostUsedMaterialsImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">
                            Frequently used raw materials in tasks
                        </h4>
                    </div>
                </a>
            </div>
            <div
                v-if="hasAccess('TASK_INCOME_OUTGOING_REPORT')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <a
                    class="text-decoration-none"
                    href=""
                    @click.prevent="
                        () => {
                            report
                                ?.getTotalIncomeAndOutgoingOfATask()
                                .then(() => {
                                    totalIncomeAndOutgoingModalRef.show();
                                    loadTotalIncomeOutgoindData();
                                });
                        }
                    "
                >
                    <img
                        :src="IncomeOutgoingReportImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">
                            Total Income and Outgoing of a Order
                        </h4>
                    </div>
                </a>
            </div>
            <div
                v-if="hasAccess('MOST_INVOLVED_EMPLOYEES_REPORT')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <a
                    class="text-decoration-none"
                    href=""
                    @click.prevent="
                        () => {
                            report?.getMostWorkedEmployees().then(() => {
                                mostWorkedEmployeesModalRef.show();
                            });
                        }
                    "
                >
                    <img
                        :src="MostWorkedEmployeesReportImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">
                            Most Involved Employees Report
                        </h4>
                    </div>
                </a>
            </div>
        </div>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import useReport from "@/composables/report";
import { useAuthUserStore } from "@/stores/authUserStore";
import { ref } from "vue";
import IncomeImage from "../../../images/undraw_savings_re_eq4w.svg";
import ItemsBelowReorderLevelImage from "../../../images/undraw_notify_re_65on.svg";
import TaskKPIImage from "../../../images/undraw_visual_data_re_mxxo.svg";
import MostUsedMaterialsImage from "../../../images/undraw_logic_re_nyb4.svg";
import IncomeOutgoingReportImage from "../../../images/undraw_transfer_money_re_6o1h.svg";
import MostWorkedEmployeesReportImage from "../../../images/undraw_feeling_proud_qne1.svg";

import { Bar, Line } from "vue-chartjs";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
} from "chart.js";

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend
);

const incomeReportModalRef = ref();
const ItemsBelowReorderLevelReportModalRef = ref();
const TaskKPIModalRef = ref();
const FrequentlyUsedRawMaterialRef = ref();
const totalIncomeAndOutgoingModalRef = ref();
const mostWorkedEmployeesModalRef = ref();
const auth = useAuthUserStore();

const hasAccess = (which_access) => {
    let ha = false;
    if (auth.reportAccess?.access_levels?.length > 0) {
        for (let i = 0; i < auth.reportAccess.access_levels?.length; i++) {
            const al = auth.reportAccess?.access_levels[i];
            if (al?.report?.title === which_access) {
                ha = al?.has_access === 1;
            }
        }
    }
    if (!ha)
        if (
            auth.user?.user_title !== "Supervisor" &&
            auth.user?.user_title !== "Manager" &&
            auth.user?.user_title !== "Employee"
        )
            return true;
    return ha;
};

const report = useReport();

const data = ref(null);
const options = {
    responsive: true,
    maintainAspectRatio: false,
};

const loadIncomeReportData = () => {
    if (report.incomeReport?.value?.orders?.length > 0) {
        data.value = {
            labels: report.incomeReport?.value?.orders?.map((order) =>
                new Date(order?.created_at).toLocaleString()
            ),
            datasets: [
                {
                    label: "Order",
                    backgroundColor: "#f87979",
                    data: report.incomeReport?.value?.orders?.map(
                        (order) => order?.estimated_price
                    ),
                },
            ],
        };
    }
};

const loadTaskKPIReportData = () => {
    if (report.taskKPIs?.value?.length > 0) {
        data.value = {
            labels: report.taskKPIs?.value?.map((task) =>
                new Date(task?.created_at).toLocaleString()
            ),
            datasets: [
                {
                    label: "Estimated Time (in Hours)",
                    backgroundColor: "#0d6efd",
                    data: report.taskKPIs?.value?.map(
                        (task) => task?.total_give_time_in_hours
                    ),
                },
                {
                    label: "Consumed Time (in Hours)",
                    backgroundColor: "#198754",
                    data: report.taskKPIs?.value?.map(
                        (task) => task?.consumed_time_in_hours
                    ),
                },
            ],
        };
    }
};

const loadFrequentlyUsedRawMaterialData = () => {
    if (report.materialUsedInTask?.value?.length > 0) {
        data.value = {
            labels: report.materialUsedInTask?.value?.map(
                (task) => `${task?.total_required_amount} ${task?.unit}`
            ),
            datasets: [
                {
                    label: "Number of Task",
                    backgroundColor: "#0d6efd",
                    data: report.materialUsedInTask?.value?.map(
                        (task) => task?.num_tasks
                    ),
                },
            ],
        };
    }
};

const loadTotalIncomeOutgoindData = () => {
    if (report.totalIncomeAndOutgoingOfAOrder?.value?.length > 0) {
        data.value = {
            labels: report.totalIncomeAndOutgoingOfAOrder?.value?.map(
                (task) => `Order ID ${task?.order_id}`
            ),
            datasets: [
                {
                    label: "Material Cost",
                    backgroundColor: "#0d6efd",
                    data: report.totalIncomeAndOutgoingOfAOrder?.value?.map(
                        (task) => task?.total_outgoing
                    ),
                },
                {
                    label: "Margin",
                    backgroundColor: "#198754",
                    data: report.totalIncomeAndOutgoingOfAOrder?.value?.map(
                        (task) => task?.estimated_cost
                    ),
                },
            ],
        };
    }
};
</script>
