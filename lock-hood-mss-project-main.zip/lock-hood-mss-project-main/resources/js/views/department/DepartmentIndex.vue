<template>
    <div class="container my-4">
        <ModalComponent
            ref="addDepartmentModalRef"
            :modal-id="'addDepartmentModal'"
            :title="'Add Department'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-6">
                        <label class="form-label">Department Title/Name</label>
                        <input
                            v-model="department.title"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Manager</label>
                        <select
                            v-model="department.manager_id"
                            class="form-select"
                        >
                            <option selected>Select Manager</option>
                            <option
                                v-for="user in users"
                                :key="user.id"
                                :value="user.id"
                            >
                                {{ user.first_name }} {{ user.last_name }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Factory</label>
                        <select
                            v-model="department.factory_id"
                            class="form-select"
                        >
                            <option selected>Select Factory</option>
                            <option
                                v-for="factory in factories"
                                :key="factory.id"
                                :value="factory.id"
                            >
                                {{ factory.title }}
                            </option>
                        </select>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="addDepartment(addDepartmentModalRef)"
                >
                    Add Department
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="editDepartmentModalRef"
            :modal-id="'editDepartmentModalRef'"
            :title="'Edit Department'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-6">
                        <label class="form-label">Department Title/Name</label>
                        <input
                            v-model="department.title"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Manager</label>
                        <select
                            v-model="department.manager_id"
                            class="form-select"
                        >
                            <option selected>Select Manager</option>
                            <option
                                v-for="user in users"
                                :key="user.id"
                                :value="user.id"
                            >
                                {{ user.first_name }} {{ user.last_name }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Factory</label>
                        <select
                            v-model="department.factory_id"
                            class="form-select"
                        >
                            <option selected>Select Factory</option>
                            <option
                                v-for="factory in factories"
                                :key="factory.id"
                                :value="factory.id"
                            >
                                {{ factory.title }}
                            </option>
                        </select>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="editDepartment(editDepartmentModalRef)"
                >
                    Edit Department
                </button>
            </template></ModalComponent
        >
        <ModalComponent
            ref="deleteDepartmentModalRef"
            :modal-id="'deleteDepartmentModal'"
            :title="'Delete Department'"
        >
            <template #body>
                <h5>Are you sure you want to delete this department?</h5>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="deleteDepartment(deleteDepartmentModalRef)"
                >
                    Delete Department
                </button></template
            ></ModalComponent
        >
        <template
            v-if="
                authUser?.user_title != 'Supervisor' &&
                authUser?.user_title != 'Manager'
            "
        >
            <div class="row">
                <div>
                    <button
                        class="btn btn-outline-primary btn-sm float-end mb-4"
                        @click="addDepartmentModalRef.show()"
                    >
                        <i class="bi bi-plus-lg"></i> Add Department
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Manager</th>
                                <th>Factory</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="dep in departments" :key="dep.id">
                                <td>{{ dep.id }}</td>
                                <td>{{ dep.title }}</td>
                                <td>
                                    {{ dep.manager.first_name }}
                                    {{ dep.manager.last_name }}
                                </td>
                                <td>
                                    {{ dep.firm.title }}
                                </td>
                                <td>
                                    <div class="d-flex gap-4">
                                        <button
                                            class="btn btn-outline-primary btn-sm"
                                            @click="
                                                () => {
                                                    department.id = dep.id;
                                                    department.title =
                                                        dep.title;
                                                    department.manager_id =
                                                        dep.manager_id;
                                                    department.factory_id =
                                                        dep.factory_id;
                                                    editDepartmentModalRef.show();
                                                }
                                            "
                                        >
                                            Edit
                                        </button>
                                        <button
                                            class="btn btn-outline-danger btn-sm"
                                            @click="
                                                () => {
                                                    department.id = dep.id;
                                                    deleteDepartmentModalRef.show();
                                                }
                                            "
                                        >
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        <template v-else-if="authUser?.user_title == 'Manager'">
            <div class="row">
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Manager</th>
                                <th>Factory</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="dep in departments">
                                <tr
                                    v-if="
                                        dep.manager.id === authUser.id ||
                                        dep.firm.manager_id === authUser.id
                                    "
                                    :key="dep.id"
                                >
                                    <td>{{ dep.id }}</td>
                                    <td>{{ dep.title }}</td>
                                    <td>
                                        {{ dep.manager.first_name }}
                                        {{ dep.manager.last_name }}
                                    </td>
                                    <td>
                                        {{ dep.firm.title }}
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        <template v-else-if="authUser?.user_title == 'Supervisor'">
            <div class="row">
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Manager</th>
                                <th>Factory</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="dep in departments">
                                <template v-for="w in dep?.workshop">
                                    <tr
                                        v-if="w.supervisor_id === authUser.id"
                                        :key="w.id"
                                    >
                                        <td>{{ dep.id }}</td>
                                        <td>{{ dep.title }}</td>
                                        <td>
                                            {{ dep.manager.first_name }}
                                            {{ dep.manager.last_name }}
                                        </td>
                                        <td>
                                            {{ dep.firm.title }}
                                        </td>
                                    </tr>
                                </template>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import useDepartment from "@/composables/department";
import useFactory from "@/composables/factory";
import useUsers from "@/composables/users";
import { useAuthUserStore } from "@/stores/authUserStore";
import { onMounted, ref } from "vue";

const {
    departments,
    department,
    getDepartments,
    addDepartment,
    editDepartment,
    deleteDepartment,
} = useDepartment();
const { users, userTitle, searchKeyword, getUsers } = useUsers();
const { factories, getFactories } = useFactory();

const addDepartmentModalRef = ref();
const editDepartmentModalRef = ref();
const deleteDepartmentModalRef = ref();

userTitle.value = "Manager";
searchKeyword.value = "all";

const authUser = useAuthUserStore().user;

onMounted(async () => {
    await getDepartments();
    await getFactories();
    await getUsers();
});
</script>
