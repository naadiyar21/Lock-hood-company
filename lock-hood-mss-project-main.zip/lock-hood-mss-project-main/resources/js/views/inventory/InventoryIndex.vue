<!-- eslint-disable vue/no-v-html -->
<template>
    <div class="container my-4">
        <ModalComponent
            ref="purchaseItemModalRef"
            :modal-id="'purchaseItemModal'"
            :title="'Purchase Item'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-3">
                        <label class="form-label">Item Name</label>
                        <input
                            v-model="inventoryItem.item"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                            disabled
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Total Amount</label>
                        <input
                            v-model="inventoryItem.quantity"
                            type="text"
                            placeholder="Total count"
                            class="form-control"
                            disabled
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Current Stock</label>
                        <input
                            v-model="inventoryItem.stock"
                            type="text"
                            placeholder="Current Stock"
                            class="form-control"
                            disabled
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Reorder Level</label>
                        <input
                            v-model="inventoryItem.reorder_level"
                            type="text"
                            placeholder="Reorder Level"
                            class="form-control"
                            disabled
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Purchase Price</label>
                        <input
                            v-model="inventoryItem.purchase_price"
                            type="text"
                            placeholder="Purchase price"
                            class="form-control"
                            disabled
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Unit of Measurement</label>
                        <select
                            v-model="inventoryItem.unit_of_measurement"
                            class="form-select"
                            aria-label="Default select example"
                            disabled
                        >
                            <option selected>Open this select menu</option>
                            <option value="kg">Kilogram (kg)</option>
                            <option value="g">Gram (g)</option>
                            <option value="m">Meter (m)</option>
                            <option value="cm">Centimeter (cm)</option>
                            <option value="l">Leter (l)</option>
                            <option value="ml">Milliliter (ml)</option>
                        </select>
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Purchase Quantity</label>
                        <input
                            v-model="inventoryItem.purchase_quantity"
                            type="text"
                            placeholder="Purchase Quantity"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-2 align-self-end">
                        <button
                            class="btn btn-outline-success"
                            type="button"
                            @click="purchaseItem(purchaseItemModalRef)"
                        >
                            Purchase
                        </button>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="addInventoryModalRef"
            :modal-id="'addInventoryModal'"
            :title="'Add Inventory Item'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-6">
                        <label class="form-label">Item Name</label>
                        <input
                            v-model="inventoryItem.item"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Quantity</label>
                        <input
                            v-model="inventoryItem.quantity"
                            type="text"
                            placeholder="Total count"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Stock</label>
                        <input
                            v-model="inventoryItem.stock"
                            type="text"
                            placeholder="Current Stock"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Reorder Level</label>
                        <input
                            v-model="inventoryItem.reorder_level"
                            type="text"
                            placeholder="Reorder Level"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Purchase Price</label>
                        <input
                            v-model="inventoryItem.purchase_price"
                            type="text"
                            placeholder="Purchase price"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Unit of Measurement</label>
                        <select
                            v-model="inventoryItem.unit_of_measurement"
                            class="form-select"
                            aria-label="Default select example"
                        >
                            <option selected>Open this select menu</option>
                            <option value="kg">Kilogram (kg)</option>
                            <option value="g">Gram (g)</option>
                            <option value="m">Meter (m)</option>
                            <option value="cm">Centimeter (cm)</option>
                            <option value="l">Leter (l)</option>
                            <option value="ml">Milliliter (ml)</option>
                        </select>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="addItem(addInventoryModalRef)"
                >
                    Add Item
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="editInventoryModalRef"
            :modal-id="'editInventoryModal'"
            :title="'Edit Inventory Item'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-2">
                        <label class="form-label">ID</label>
                        <input
                            v-model="inventoryItem.id"
                            disabled
                            type="text"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-6">
                        <label class="form-label">Item Name</label>
                        <input
                            v-model="inventoryItem.item"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Quantity</label>
                        <input
                            v-model="inventoryItem.quantity"
                            type="text"
                            placeholder="Total count"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Stock</label>
                        <input
                            v-model="inventoryItem.stock"
                            type="text"
                            placeholder="Current Stock"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Reorder Level</label>
                        <input
                            v-model="inventoryItem.reorder_level"
                            type="text"
                            placeholder="Reorder Level"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Purchase Price</label>
                        <input
                            v-model="inventoryItem.purchase_price"
                            type="text"
                            placeholder="Purchase price"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Unit of Measurement</label>
                        <select
                            v-model="inventoryItem.unit_of_measurement"
                            class="form-select"
                            aria-label="Default select example"
                        >
                            <option selected>Open this select menu</option>
                            <option value="kg">Kilogram (kg)</option>
                            <option value="g">Gram (g)</option>
                            <option value="m">Meter (m)</option>
                            <option value="cm">Centimeter (cm)</option>
                            <option value="l">Leter (l)</option>
                            <option value="ml">Milliliter (ml)</option>
                        </select>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="editItem(editInventoryModalRef)"
                >
                    Edit Item
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="deleteInventoryModalRef"
            :modal-id="'deleteInventoryModal'"
            :title="'Delete Inventory Item'"
        >
            <template #body>
                <h5>Are you sure you want to delete this item?</h5>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-danger"
                    @click="deleteItem(deleteInventoryModalRef)"
                >
                    Delete Item
                </button>
            </template>
        </ModalComponent>

        <div class="row">
            <div>
                <button
                    class="btn btn-outline-primary btn-sm float-end mb-4"
                    @click="addInventoryModalRef.show()"
                >
                    <i class="bi bi-plus-lg"></i> Add Item
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Stock</th>
                            <th>Reorder Level</th>
                            <th>Purchase Price</th>
                            <th>Unit of Measurement</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="item in items?.data" :key="item.id">
                            <td>{{ item.id }}</td>
                            <td>{{ item.item }}</td>
                            <td>{{ item.quantity }}</td>
                            <td>{{ item.stock }}</td>
                            <td>{{ item.reorder_level }}</td>
                            <td>{{ item.purchase_price }}</td>
                            <td>{{ item.unit_of_measurement }}</td>
                            <td>
                                <div class="d-flex gap-3">
                                    <button
                                        class="btn btn-outline-primary btn-sm"
                                        @click="
                                            () => {
                                                inventoryItem.id = item.id;
                                                inventoryItem.item = item.item;
                                                inventoryItem.purchase_price =
                                                    item.purchase_price;
                                                inventoryItem.quantity =
                                                    item.quantity;
                                                inventoryItem.reorder_level =
                                                    item.reorder_level;
                                                inventoryItem.stock =
                                                    item.stock;
                                                inventoryItem.unit_of_measurement =
                                                    item.unit_of_measurement;
                                                editInventoryModalRef.show();
                                            }
                                        "
                                    >
                                        Edit
                                    </button>
                                    <button
                                        class="btn btn-outline-primary btn-sm"
                                        @click="
                                            () => {
                                                inventoryItem.id = item.id;
                                                inventoryItem.item = item.item;
                                                inventoryItem.purchase_price =
                                                    item.purchase_price;
                                                inventoryItem.quantity =
                                                    item.quantity;
                                                inventoryItem.reorder_level =
                                                    item.reorder_level;
                                                inventoryItem.stock =
                                                    item.stock;
                                                inventoryItem.unit_of_measurement =
                                                    item.unit_of_measurement;

                                                purchaseItemModalRef.show();
                                            }
                                        "
                                    >
                                        Purchase
                                    </button>
                                    <button
                                        class="btn btn-outline-danger btn-sm"
                                        @click="
                                            () => {
                                                inventoryItem.id = item.id;
                                                deleteInventoryModalRef.show();
                                            }
                                        "
                                    >
                                        Delete
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <PaginatorComponent :items="items" @get-items="getItems" />
        </div>
    </div>
</template>

<script setup>
import { onMounted, ref } from "vue";
import useInventory from "@/composables/inventory";
import ModalComponent from "@/components/ModalComponent.vue";
import PaginatorComponent from "@/components/PaginatorComponent.vue";

const {
    inventoryItem,
    items,
    addItem,
    getItems,
    editItem,
    deleteItem,
    purchaseItem,
} = useInventory();

const addInventoryModalRef = ref();
const editInventoryModalRef = ref();
const deleteInventoryModalRef = ref();
const purchaseItemModalRef = ref();

onMounted(() => {
    getItems();
});
</script>
