<template>
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="card p-3 mt-md-5 col-md-6 m-2">
                <form class="row" @submit.prevent="register">
                    <div class="mb-3 col-md-6">
                        <label class="form-label">First Name</label>
                        <input
                            v-model="regUser.first_name"
                            type="text"
                            placeholder="First Name"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Last Name</label>
                        <input
                            v-model="regUser.last_name"
                            type="text"
                            placeholder="Last Name"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Email</label>
                        <input
                            v-model="regUser.email"
                            type="email"
                            placeholder="email@example.com"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Phone</label>
                        <input
                            v-model="regUser.phone"
                            type="text"
                            placeholder="Your Contact No"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-12">
                        <label class="form-label">Address 1</label>
                        <input
                            v-model="regUser.address1"
                            type="text"
                            placeholder="Address 1"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-12">
                        <label class="form-label">Address 2</label>
                        <input
                            v-model="regUser.address2"
                            type="text"
                            placeholder="Address 2"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Password</label>
                        <input
                            v-model="regUser.password"
                            type="password"
                            required
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Confirm Password</label>
                        <input
                            v-model="regUser.password_confirmation"
                            type="password"
                            required
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">User Title</label>
                        <select
                            v-model="regUser.user_title"
                            class="form-select"
                            aria-label="Default select example"
                            required
                        >
                            <option selected>Open this select menu</option>
                            <option value="Manager">Manager</option>
                            <option value="Supervisor">Supervisor</option>
                            <option value="Employee">Employee</option>
                        </select>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Joined Date</label>
                        <input
                            v-model="regUser.joined_date"
                            type="date"
                            class="form-control"
                        />
                    </div>
                    <div>
                        <button
                            class="btn btn-outline-success float-end"
                            type="submit"
                        >
                            Register
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
import useAuth from "@/composables/auth";

const { regUser, register } = useAuth();
</script>
