<template>
    <div class="container">
        <form class="row justify-content-md-center" @submit.prevent="login">
            <div class="card p-3 mt-5 col-md-5">
                <div class="mb-3">
                    <label class="form-label">Eamil</label>
                    <input
                        v-model="loginCredentials.email"
                        type="email"
                        class="form-control"
                        placeholder="name@example.com"
                    />
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input
                        v-model="loginCredentials.password"
                        type="password"
                        class="form-control"
                    />
                </div>
                <div>
                    <button
                        class="btn btn-outline-success float-end"
                        type="submit"
                    >
                        Login
                    </button>
                </div>
            </div>
        </form>
    </div>
</template>

<script setup>
import { ref } from "vue";
import useAuth from "@/composables/auth";

const { loginCredentials, login } = useAuth();
</script>
