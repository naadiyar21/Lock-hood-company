<template>
    <div class="container my-4">
        <ModalComponent
            ref="addFactoryModalRef"
            :modal-id="'addFactoryModal'"
            :title="'Add Factory'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-8">
                        <label class="form-label">Factory Title/Name</label>
                        <input
                            v-model="factory.title"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Manager</label>
                        <select
                            v-model="factory.manager_id"
                            class="form-select"
                        >
                            <option selected>Select Manager</option>
                            <option
                                v-for="user in users"
                                :key="user.id"
                                :value="user.id"
                            >
                                {{ user.first_name }} {{ user.last_name }}
                            </option>
                        </select>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="addFactory(addFactoryModalRef)"
                >
                    Add Factory
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="editFactoryModalRef"
            :modal-id="'editFactoryModalRef'"
            :title="'Edit Factory'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-8">
                        <label class="form-label">Factory Title/Name</label>
                        <input
                            v-model="factory.title"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-4">
                        <label class="form-label">Manager</label>
                        <select
                            v-model="factory.manager_id"
                            class="form-select"
                        >
                            <option selected>Select Manager</option>
                            <option
                                v-for="user in users"
                                :key="user.id"
                                :value="user.id"
                            >
                                {{ user.first_name }} {{ user.last_name }}
                            </option>
                        </select>
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="editFactory(editFactoryModalRef)"
                >
                    Edit Factory
                </button>
            </template></ModalComponent
        >
        <ModalComponent
            ref="deleteFactoryModalRef"
            :modal-id="'deleteFactoryModal'"
            :title="'Delete Factory'"
        >
            <template #body>
                <h5>Are you sure you want to delete this factory?</h5>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="deleteFactory(deleteFactoryModalRef)"
                >
                    Delete Factory
                </button></template
            ></ModalComponent
        >

        <template
            v-if="
                authUser?.user_title != 'Supervisor' &&
                authUser?.user_title != 'Manager'
            "
        >
            <div class="row">
                <div>
                    <button
                        class="btn btn-outline-primary btn-sm float-end mb-4"
                        @click="addFactoryModalRef.show()"
                    >
                        <i class="bi bi-plus-lg"></i> Add Factory
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Manager</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="fac in factories" :key="fac.id">
                                <td>{{ fac.id }}</td>
                                <td>{{ fac.title }}</td>
                                <td>
                                    {{ fac.manager.first_name }}
                                    {{ fac.manager.last_name }}
                                </td>
                                <td>
                                    <div class="d-flex gap-4">
                                        <button
                                            class="btn btn-outline-primary btn-sm"
                                            @click="
                                                () => {
                                                    factory.id = fac.id;
                                                    factory.title = fac.title;
                                                    factory.manager_id =
                                                        fac.manager.id;
                                                    editFactoryModalRef.show();
                                                }
                                            "
                                        >
                                            Edit
                                        </button>
                                        <button
                                            class="btn btn-outline-danger btn-sm"
                                            @click="
                                                () => {
                                                    factory.id = fac.id;
                                                    deleteFactoryModalRef.show();
                                                }
                                            "
                                        >
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        <template v-else-if="authUser.user_title === 'Manager'">
            <div class="row">
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Manager</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="fac in factories">
                                <tr
                                    v-if="fac.manager_id === authUser.id"
                                    :key="fac.id"
                                >
                                    <td>{{ fac.id }}</td>
                                    <td>{{ fac.title }}</td>
                                    <td>
                                        {{ fac.manager.first_name }}
                                        {{ fac.manager.last_name }}
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        <template v-else-if="authUser.user_title === 'Supervisor'">
            <div class="row">
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Manager</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="fac in factories">
                                <template v-for="d in fac?.departments">
                                    <template v-for="w in d?.workshop">
                                        <tr
                                            v-if="
                                                w.supervisor_id === authUser.id
                                            "
                                            :key="w.id"
                                        >
                                            <td>{{ fac.id }}</td>
                                            <td>{{ fac.title }}</td>
                                            <td>
                                                {{ fac.manager.first_name }}
                                                {{ fac.manager.last_name }}
                                            </td>
                                        </tr>
                                    </template>
                                </template>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import useFactory from "@/composables/factory";
import useUsers from "@/composables/users";
import { useAuthUserStore } from "@/stores/authUserStore";
import { onMounted, ref } from "vue";

const {
    factories,
    factory,
    getFactories,
    addFactory,
    editFactory,
    deleteFactory,
} = useFactory();
const { users, userTitle, searchKeyword, getUsers } = useUsers();

const addFactoryModalRef = ref();
const editFactoryModalRef = ref();
const deleteFactoryModalRef = ref();

const authUser = useAuthUserStore().user;
userTitle.value = "Manager";
searchKeyword.value = "all";
onMounted(async () => {
    await getFactories();
    await getUsers();
});
</script>
