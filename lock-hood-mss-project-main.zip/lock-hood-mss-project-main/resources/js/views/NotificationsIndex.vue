<template>
    <div class="container-fluid">
        <ul id="myTab" class="nav nav-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button
                    id="uread-notifications-tab"
                    class="nav-link active"
                    data-bs-toggle="tab"
                    data-bs-target="#uread-notifications-tab-pane"
                    type="button"
                    role="tab"
                    aria-controls="uread-notifications-tab-pane"
                    aria-selected="true"
                >
                    Unread Notifications
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button
                    id="all-notifications-tab"
                    class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#all-notifications-tab-pane"
                    type="button"
                    role="tab"
                    aria-controls="all-notifications-tab-pane"
                    aria-selected="false"
                >
                    All Notifications
                </button>
            </li>
        </ul>
        <div id="myTabContent" class="tab-content">
            <div
                id="uread-notifications-tab-pane"
                class="tab-pane fade show active"
                role="tabpanel"
                aria-labelledby="uread-notifications-tab"
                tabindex="0"
            >
                <div class="container mt-4">
                    <template v-if="allUnreadNotifications.length > 0">
                        <div
                            v-for="notfication in allUnreadNotifications"
                            :key="notfication.id"
                            class="alert alert-warning"
                            role="alert"
                        >
                            [{{
                                new Date(
                                    notfication.created_at
                                ).toLocaleString()
                            }}] Item
                            <strong>'{{ notfication?.data?.item }}'</strong> hit
                            the reorder level. (Current Stock:
                            {{ notfication?.data?.stock }}, Reorder level:
                            {{ notfication?.data?.reorder_level }})

                            <a
                                href=""
                                class="float-end"
                                @click.prevent="markAsRead(notfication.id)"
                                >Mark as read</a
                            >
                        </div>
                    </template>
                    <template v-else> <h5>No new notifications</h5> </template>
                    <a
                        v-if="allUnreadNotifications.length > 0"
                        href=""
                        @click.prevent="markAsRead(null)"
                        >Mark all as read</a
                    >
                </div>
            </div>
            <div
                id="all-notifications-tab-pane"
                class="tab-pane fade"
                role="tabpanel"
                aria-labelledby="all-notifications-tab"
                tabindex="0"
            >
                <div class="container mt-4">
                    <div
                        v-for="notfication in allNotifications"
                        :key="notfication.id"
                        class="alert alert-warning"
                        role="alert"
                    >
                        [{{
                            new Date(notfication.created_at).toLocaleString()
                        }}] Item
                        <strong>'{{ notfication?.data?.item }}'</strong> hit the
                        reorder level. (Current Stock:
                        {{ notfication?.data?.stock }}, Reorder level:
                        {{ notfication?.data?.reorder_level }})
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import useNotification from "@/composables/notification";
import { onMounted } from "vue";

const {
    allNotifications,
    allUnreadNotifications,
    getAllNotifications,
    getAllUnreadNotifications,
    markAsRead,
} = useNotification();

onMounted(() => {
    getAllNotifications();
    getAllUnreadNotifications();
});
</script>
