<template>
    <div class="container my-4">
        <ModalComponent
            ref="addWorkshopModalRef"
            :modal-id="'addWorkshopModal'"
            :title="'Add Workshop'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-4">
                        <label class="form-label">Workshop Title/Name</label>
                        <input
                            v-model="workshop.title"
                            type="text"
                            placeholder="Title/Name of the Workshop"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Supervisor</label>
                        <select
                            v-model="workshop.supervisor_id"
                            class="form-select"
                        >
                            <option selected>Select Supervisor</option>
                            <option
                                v-for="user in users"
                                :key="user.id"
                                :value="user.id"
                            >
                                {{ user.first_name }} {{ user.last_name }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Department</label>
                        <select
                            v-model="workshop.department_id"
                            class="form-select"
                        >
                            <option selected>Select Department</option>
                            <option
                                v-for="department in departments"
                                :key="department.id"
                                :value="department.id"
                            >
                                {{ department.title }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Total Space</label>
                        <input
                            v-model="workshop.total_space"
                            type="text"
                            placeholder="Total Space"
                            class="form-control"
                        />
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="addWorkshop(addWorkshopModalRef)"
                >
                    Add Workshop
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="editWorkshopModalRef"
            :modal-id="'editWorkshopModalRef'"
            :title="'Edit Workshop'"
        >
            <template #body>
                <form class="row">
                    <div class="mb-3 col-4">
                        <label class="form-label">Workshop Title/Name</label>
                        <input
                            v-model="workshop.title"
                            type="text"
                            placeholder="Name of the Item"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Supervisor</label>
                        <select
                            v-model="workshop.supervisor_id"
                            class="form-select"
                        >
                            <option selected>Select Supervisor</option>
                            <option
                                v-for="user in users"
                                :key="user.id"
                                :value="user.id"
                            >
                                {{ user.first_name }} {{ user.last_name }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3 col-3">
                        <label class="form-label">Department</label>
                        <select
                            v-model="workshop.department_id"
                            class="form-select"
                        >
                            <option selected>Select Department</option>
                            <option
                                v-for="department in departments"
                                :key="department.id"
                                :value="department.id"
                            >
                                {{ department.title }}
                            </option>
                        </select>
                    </div>
                    <div class="mb-3 col-2">
                        <label class="form-label">Total Space</label>
                        <input
                            v-model="workshop.total_space"
                            type="text"
                            placeholder="Total Space"
                            class="form-control"
                        />
                    </div>
                </form>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="editWorkshop(editWorkshopModalRef)"
                >
                    Edit Workshop
                </button>
            </template></ModalComponent
        >
        <ModalComponent
            ref="deleteWorkshopModalRef"
            :modal-id="'deleteWorkshopModal'"
            :title="'Delete Workshop'"
        >
            <template #body>
                <h5>Are you sure you want to delete this workshop?</h5>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="deleteWorkshop(deleteWorkshopModalRef)"
                >
                    Delete Workshop
                </button></template
            ></ModalComponent
        >
        <template
            v-if="
                authUser?.user_title != 'Supervisor' &&
                authUser?.user_title != 'Manager'
            "
        >
            <div class="row">
                <div>
                    <button
                        class="btn btn-outline-primary btn-sm float-end mb-4"
                        @click="addWorkshopModalRef.show()"
                    >
                        <i class="bi bi-plus-lg"></i> Add Workshop
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title/Name</th>
                                <th>Supervisor</th>
                                <th>Department</th>
                                <th>Total Space</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="ws in workshops" :key="ws.id">
                                <td>{{ ws.id }}</td>
                                <td>{{ ws.title }}</td>
                                <td>
                                    {{ ws.supervisor.first_name }}
                                    {{ ws.supervisor.last_name }}
                                </td>
                                <td>{{ ws.department.title }}</td>
                                <td>{{ ws.total_space }}</td>
                                <td>
                                    <div class="d-flex gap-4">
                                        <button
                                            class="btn btn-outline-primary btn-sm"
                                            @click="
                                                () => {
                                                    workshop.id = ws.id;
                                                    workshop.supervisor_id =
                                                        ws.supervisor_id;
                                                    workshop.department_id =
                                                        ws.department_id;
                                                    workshop.title = ws.title;
                                                    workshop.total_space =
                                                        ws.total_space;
                                                    editWorkshopModalRef.show();
                                                }
                                            "
                                        >
                                            Edit
                                        </button>
                                        <button
                                            class="btn btn-outline-danger btn-sm"
                                            @click="
                                                () => {
                                                    workshop.id = ws.id;
                                                    deleteWorkshopModalRef.show();
                                                }
                                            "
                                        >
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
        <template v-else-if="authUser?.user_title == 'Supervisor'">
            <div class="table-responsive">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title/Name</th>
                            <th>Supervisor</th>
                            <th>Department</th>
                            <th>Total Space</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template v-for="ws in workshops">
                            <tr
                                v-if="ws.supervisor.id === authUser.id"
                                :key="ws.id"
                            >
                                <td>{{ ws.id }}</td>
                                <td>{{ ws.title }}</td>
                                <td>
                                    {{ ws.supervisor.first_name }}
                                    {{ ws.supervisor.last_name }}
                                </td>
                                <td>{{ ws.department.title }}</td>
                                <td>{{ ws.total_space }}</td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </template>
        <template v-else-if="authUser?.user_title == 'Manager'">
            <div class="table-responsive">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title/Name</th>
                            <th>Supervisor</th>
                            <th>Department</th>
                            <th>Total Space</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template v-for="ws in workshops">
                            <tr
                                v-if="
                                    ws.department.manager_id === authUser.id ||
                                    ws.department.firm.manager_id ===
                                        authUser.id
                                "
                                :key="ws.id"
                            >
                                <td>{{ ws.id }}</td>
                                <td>{{ ws.title }}</td>
                                <td>
                                    {{ ws.supervisor.first_name }}
                                    {{ ws.supervisor.last_name }}
                                </td>
                                <td>{{ ws.department.title }}</td>
                                <td>{{ ws.total_space }}</td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </template>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import useDepartment from "@/composables/department";
import useUsers from "@/composables/users";
import useWorkshop from "@/composables/workshop";
import { useAuthUserStore } from "@/stores/authUserStore";
import { ref, onMounted } from "vue";

const addWorkshopModalRef = ref();
const editWorkshopModalRef = ref();
const deleteWorkshopModalRef = ref();

const {
    workshop,
    workshops,
    getWorkshops,
    addWorkshop,
    editWorkshop,
    deleteWorkshop,
} = useWorkshop();

const { users, userTitle, searchKeyword, getUsers } = useUsers();
const { departments, getDepartments } = useDepartment();

userTitle.value = "Supervisor";
searchKeyword.value = "all";

const authUser = useAuthUserStore().user;

onMounted(() => {
    getWorkshops();
    getUsers();
    getDepartments();
});
</script>
