<template>
    <div class="container my-4">
        <ModalComponent
            ref="selectWorkersModalRef"
            :modal-id="'selectWorkersModal'"
            :title="'Select workers for this project'"
        >
            <template #body>
                <div class="row">
                    <div class="mb-2">
                        <input
                            v-model="employeesSearchKeyword"
                            type="text"
                            class="form-control"
                            placeholder="Search Workers/Employee"
                            @input="getEmployees(null)"
                        />
                    </div>
                    <div>
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Joined Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="emp in availableEmployees"
                                    :key="emp.id"
                                >
                                    <td>{{ emp.id }}</td>
                                    <td>
                                        {{ emp.first_name }} {{ emp.last_name }}
                                    </td>
                                    <td>{{ emp.phone }}</td>
                                    <td>{{ emp.email }}</td>
                                    <td>
                                        {{ emp.joined_date }}
                                    </td>
                                    <td>
                                        <div class="form-check">
                                            <input
                                                v-model="task.workers_ids"
                                                class="form-check-input"
                                                type="checkbox"
                                                :disabled="
                                                    emp.already_working &&
                                                    !task.workers_ids.includes(
                                                        emp.id
                                                    ) &&
                                                    emp.working_line[0]
                                                        .task_id != task.id
                                                "
                                                :value="emp.id"
                                            />
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <PaginatorComponent
                            :items="employees"
                            @get-items="getEmployees"
                        />
                    </div>
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="selectMaterialsModalRef"
            :modal-id="'selectMaterialsModal'"
            :title="'Select materials for this project'"
        >
            <template #body>
                <div class="row">
                    <div class="mb-2">
                        <input
                            v-model="employeesSearchKeyword"
                            type="text"
                            class="form-control"
                            placeholder="Search Workers/Employee"
                            @input="getEmployees(null)"
                        />
                    </div>
                    <div
                        class="table-responsive mb-4"
                        style="max-height: 300px"
                    >
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Item</th>
                                    <th>Reorder Level</th>
                                    <th>Stock</th>
                                    <th>Purchase Price</th>
                                    <th>Unit of measurement</th>
                                    <th>Required Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="it in globalStore.materials?.data"
                                    :key="it.id"
                                >
                                    <td>{{ it.id }}</td>
                                    <td>{{ it.item }}</td>
                                    <td>{{ it.reorder_level }}</td>
                                    <td>{{ it.stock }}</td>
                                    <td>{{ it.purchase_price }}</td>
                                    <td>{{ it.unit_of_measurement }}</td>
                                    <td>
                                        <input
                                            :id="`${it.id}${it.stock}`"
                                            type="number"
                                            class="form-control form-control-sm"
                                            :value="it?.required_amount"
                                            @input="
                                                (e) => {
                                                    addRequiredAmount(e, it.id);
                                                    totalCostCalculate();
                                                }
                                            "
                                        />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="createCustomerModalRef"
            :modal-id="'createCustomerModal'"
            :title="'Create a Customer'"
        >
            <template #body>
                <div class="row">
                    <div class="col-12 col-md-6 mb-4">
                        <label class="form-label">First Name</label>
                        <input
                            v-model="customer.first_name"
                            type="text"
                            class="form-control"
                        />
                    </div>
                    <div class="col-12 col-md-6 mb-4">
                        <label class="form-label">Last Name</label>
                        <input
                            v-model="customer.last_name"
                            type="text"
                            class="form-control"
                        />
                    </div>
                    <div class="col-12 col-md-6 mb-4">
                        <label class="form-label">Email</label>
                        <input
                            v-model="customer.email"
                            type="email"
                            class="form-control"
                        />
                    </div>
                    <div class="col-12 col-md-6 mb-4">
                        <label class="form-label">Phone</label>
                        <input
                            v-model="customer.phone"
                            type="text"
                            class="form-control"
                        />
                    </div>
                    <div class="col-12 mb-4">
                        <label class="form-label">Address 1</label>
                        <input
                            v-model="customer.address1"
                            type="text"
                            class="form-control"
                        />
                    </div>
                    <div class="col-12 mb-4">
                        <label class="form-label">Address 2</label>
                        <input
                            v-model="customer.address2"
                            type="text"
                            class="form-control"
                        />
                    </div>
                </div>
            </template>
            <template #footer>
                <button
                    class="btn btn-outline-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    class="btn btn-outline-success"
                    @click="
                        () => {
                            customer.user_title = 'Customer';
                            addCustomer(createCustomerModalRef);
                        }
                    "
                >
                    Add Customer
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="showWorkersModalRef"
            :modal-id="'showWorkersModal'"
            :title="'Workers/Employees of this task'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <div>
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address 1</th>
                                <th>Address 2</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="c in currentlyShowingWorkers"
                                :key="c.id"
                            >
                                <td>{{ c.id }}</td>
                                <td>{{ c.first_name }} {{ c.last_name }}</td>
                                <td>{{ c.email }}</td>
                                <td>{{ c.phone }}</td>
                                <td>{{ c.address1 }}</td>
                                <td>{{ c.address2 }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
            <template #footer>
                <button
                    class="btn btn-outline-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="showMaterialsModalRef"
            :modal-id="'showMaterialsModal'"
            :title="'Materials used in this task'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <div style="max-height: 350px">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Item</th>
                                <th>Purchase Price</th>
                                <th>Stock</th>
                                <th>Used Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr
                                v-for="c in currentlyShowingMaterials"
                                :key="c.id"
                            >
                                <td>{{ c.id }}</td>
                                <td>{{ c.item }}</td>
                                <td>{{ c.purchase_price }}</td>
                                <td>{{ c.stock }}</td>
                                <td>{{ c.pivot.required_amount }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
            <template #footer>
                <button
                    class="btn btn-outline-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="deleteTaskModalRef"
            :modal-id="'editTaskModal'"
            :title="'Confirmation'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <h4>Are you sure you want to delete this task?</h4>
            </template>
            <template #footer>
                <button
                    class="btn btn-outline-danger"
                    data-bs-dismiss="modal"
                    @click="deleteTask"
                >
                    Delete
                </button>
                <button
                    class="btn btn-outline-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="taskDoneModalRef"
            :modal-id="'doneTaskModal'"
            :title="'Confirmation'"
            :modal-size="'modal-xl'"
        >
            <template #body>
                <h4>Are you sure you want to set this task as done?</h4>
            </template>
            <template #footer>
                <button
                    class="btn btn-outline-success"
                    data-bs-dismiss="modal"
                    @click="doneTask"
                >
                    Set as done
                </button>
                <button
                    class="btn btn-outline-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <template v-if="userTitle !== 'Employee'">
            <div class="row">
                <div class="col-md-4 col-full mb-4">
                    <label class="form-label">Customer</label>
                    <div class="input-group">
                        <select
                            v-model="task.customer_id"
                            class="form-select"
                            aria-label="Default select example"
                        >
                            <option selected>Select customer for order</option>
                            <option
                                v-for="cus in customers?.data"
                                :key="cus.id"
                                :value="cus.id"
                            >
                                {{ cus.first_name }} {{ cus.last_name }}
                            </option>
                        </select>
                        <button
                            class="btn btn-outline-primary"
                            type="button"
                            @click="createCustomerModalRef.show()"
                        >
                            Create Customer
                        </button>
                    </div>
                </div>
                <div class="col-md-4 col-full mb-4">
                    <label class="form-label">Task Title/Description</label>
                    <input
                        v-model="task.title"
                        type="text"
                        class="form-control"
                    />
                </div>
                <div class="col-md-2 col-7 mb-4">
                    <label class="form-label">Workshop</label>
                    <select
                        v-model="task.workshop_id"
                        class="form-select"
                        aria-label="Default select example"
                        @change="getAvailableWorkspaces(task.workshop_id)"
                    >
                        <option selected>Select workshop</option>
                        <option
                            v-for="ws in workshops"
                            :key="ws.id"
                            :value="ws.id"
                        >
                            {{ ws.title }}
                        </option>
                    </select>
                </div>
                <div class="col-md-2 col-5 mb-4">
                    <label class="form-label">Available Spaces</label>
                    <input
                        type="text"
                        class="form-control"
                        :value="avaiableWorkspaces"
                        disabled
                    />
                </div>
                <div class="col-md-2 col-5 mb-4">
                    <label class="form-label">Requried Spaces</label>
                    <input
                        v-model="task.required_space"
                        type="number"
                        class="form-control"
                        :max="avaiableWorkspaces"
                        min="1"
                    />
                </div>
                <div class="col-md-2 col-12 mb-4 align-self-end">
                    <label class="form-label">Workers on this project</label>
                    <div class="d-grid">
                        <button
                            class="btn"
                            :class="{
                                'btn-outline-dark':
                                    task.workers_ids.length <= 0,
                                'btn-outline-success':
                                    task.workers_ids.length >= 1,
                            }"
                            @click="selectWorkersModalRef.show()"
                        >
                            Select Workers
                        </button>
                    </div>
                </div>
                <div class="col-md-2 col-12 mb-4 align-self-end">
                    <label class="form-label">Materials for this order</label>
                    <div class="d-grid">
                        <button
                            class="btn"
                            :class="{
                                'btn-outline-dark': task.materials.length <= 0,
                                'btn-outline-success':
                                    task.materials.length >= 1,
                            }"
                            @click="selectMaterialsModalRef.show()"
                        >
                            Select Materials
                        </button>
                    </div>
                </div>
                <div class="col-md-2 col-12 mb-4">
                    <label class="form-label">Cost of Materials</label>
                    <input
                        id="costOfMaterials"
                        type="text"
                        class="form-control"
                        :value="costOfMaterials"
                        disabled
                    />
                </div>
                <div class="col-md-2 col-12 mb-4">
                    <label class="form-label">Margin for the order</label>
                    <input
                        v-model="task.margin"
                        type="text"
                        class="form-control"
                        @input="totalCostCalculate"
                    />
                </div>
                <div class="col-md-2 col-12 mb-4">
                    <label class="form-label">Total Cost of the order</label>
                    <input
                        type="text"
                        class="form-control"
                        :value="totalCost"
                        disabled
                    />
                </div>
                <div class="col-md-4 col-12 mb-4">
                    <label class="form-label"
                        >Estimated Time of Order (From Now)</label
                    >
                    <div class="input-group">
                        <input
                            v-model="task.estimated_time"
                            type="text"
                            class="form-control"
                        />
                        <select
                            v-model="task.estimated_time_unit"
                            class="form-select"
                        >
                            <option value="days">Days</option>
                            <option value="weeks">Weeks</option>
                            <option value="months">Months</option>
                            <option value="years">Years</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2 col-12 mb-4 align-self-end">
                    <div class="d-grid">
                        <button
                            class="btn btn-outline-success"
                            :disabled="editTask"
                            @click="
                                () => {
                                    addTask().then(() => {
                                        avaiableWorkspaces = 0;
                                    });
                                }
                            "
                        >
                            Create Task
                        </button>
                    </div>
                </div>
                <div class="col-md-2 col-12 mb-4 align-self-end">
                    <div class="d-grid">
                        <button
                            class="btn btn-outline-primary"
                            :disabled="!editTask"
                            @click="updateTask(avaiableWorkspaces)"
                        >
                            Edit Task
                        </button>
                    </div>
                </div>
                <div class="col-md-2 col-12 mb-4 align-self-end">
                    <div class="d-grid">
                        <button
                            class="btn btn-outline-danger"
                            :disabled="!editTask"
                            @click="deleteTaskModalRef.show()"
                        >
                            Delete Task
                        </button>
                    </div>
                </div>
                <div class="col-md-2 col-12 mb-4 align-self-end">
                    <div class="d-grid">
                        <button
                            class="btn btn-outline-success"
                            :disabled="!editTask"
                            @click="taskDoneModalRef.show()"
                        >
                            Set This Task as Done
                        </button>
                    </div>
                </div>
            </div>
            <hr />
            <div class="table-responsive">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Task Title</th>
                            <th>Workshop</th>
                            <th>Required Space</th>
                            <th>Workers</th>
                            <th>Materials</th>
                            <th>Cost of Materials</th>
                            <th>Margin for the order</th>
                            <th>Total cost of the order</th>
                            <th>Estimated Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr
                            v-for="t in tasks?.data"
                            :key="t.id"
                            :class="{
                                'table-success': t.is_done,
                                'table-danger': !t.is_done,
                            }"
                        >
                            <td>{{ t.id }}</td>
                            <td>
                                {{ t.order.customer.first_name }}
                                {{ t.order.customer.last_name }}
                            </td>
                            <td>{{ t.title }}</td>
                            <td>{{ t.workshop[0].title }}</td>
                            <td>{{ t.working_line.required_space }}</td>
                            <td>
                                <button
                                    class="btn btn-outline-secondary btn-sm"
                                    @click="
                                        () => {
                                            currentlyShowingWorkers =
                                                t?.working_line?.employees;
                                            showWorkersModalRef.show();
                                        }
                                    "
                                >
                                    Show Workers
                                </button>
                            </td>
                            <td>
                                <button
                                    class="btn btn-outline-secondary btn-sm"
                                    @click="
                                        () => {
                                            currentlyShowingMaterials =
                                                t?.items;
                                            showMaterialsModalRef.show();
                                        }
                                    "
                                >
                                    Show Materials
                                </button>
                            </td>
                            <td>{{ getMaterialCost(t) }}</td>
                            <td>{{ t.estimated_cost.toFixed(2) }}</td>
                            <td>
                                {{
                                    (
                                        +t.estimated_cost + +getMaterialCost(t)
                                    ).toFixed(2)
                                }}
                            </td>
                            <td>{{ t.estimated_time }}</td>
                            <td>
                                <button
                                    class="btn btn-outline-primary btn-sm"
                                    :disabled="t.is_done"
                                    @click="setSetEditTaskValues(t)"
                                >
                                    Edit
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </template>
        <template v-else>
            <div class="table-responsive">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Task Title</th>
                            <th>Workshop</th>
                            <th>Required Space</th>
                            <th>Workers</th>
                            <th>Materials</th>
                            <th>Estimated Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr
                            v-for="t in tasks?.data"
                            :key="t.id"
                            :class="{
                                'table-success': t.is_done,
                                'table-danger': !t.is_done,
                            }"
                        >
                            <td>{{ t.id }}</td>
                            <td>{{ t.title }}</td>
                            <td>{{ t.workshop[0].title }}</td>
                            <td>{{ t.working_line.required_space }}</td>
                            <td>
                                <button
                                    class="btn btn-outline-secondary btn-sm"
                                    @click="
                                        () => {
                                            currentlyShowingWorkers =
                                                t?.working_line?.employees;
                                            showWorkersModalRef.show();
                                        }
                                    "
                                >
                                    Show Workers
                                </button>
                            </td>
                            <td>
                                <button
                                    class="btn btn-outline-secondary btn-sm"
                                    @click="
                                        () => {
                                            currentlyShowingMaterials =
                                                t?.items;
                                            showMaterialsModalRef.show();
                                        }
                                    "
                                >
                                    Show Materials
                                </button>
                            </td>
                            <td>{{ t.estimated_time }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </template>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import useUsers from "@/composables/users";
import useWorkshop from "@/composables/workshop";
import useTask from "@/composables/task";
import { ref, onMounted, computed } from "vue";
import PaginatorComponent from "@/components/PaginatorComponent.vue";
import useInventory from "@/composables/inventory";
import { useAuthUserStore } from "@/stores/authUserStore";
import { useGlobalStore } from "@/stores/globalStore";

const createCustomerModalRef = ref();
const selectWorkersModalRef = ref();
const selectMaterialsModalRef = ref();
const showWorkersModalRef = ref();
const showMaterialsModalRef = ref();
const deleteTaskModalRef = ref();
const taskDoneModalRef = ref();

const {
    user: customer,
    users: customers,
    userTitle: customerUserTitle,
    addUser: addCustomer,
    getUsers: getCustomers,
} = useUsers();

const {
    users: employees,
    availableEmployees,
    userTitle: employeesUserTitle,
    searchKeyword: employeesSearchKeyword,
    getUsers: getEmployees,
} = useUsers();

const { workshops, avaiableWorkspaces, getAvailableWorkspaces, getWorkshops } =
    useWorkshop();

const {
    task,
    tasks,
    totalCost,
    currentlyShowingWorkers,
    currentlyShowingMaterials,
    editTask,
    doneTask,
    deleteTask,
    addRequiredAmount,
    setEditTaskValues,
    addTask,
    getTasks,
    getMaterialCost,
    updateTask,
} = useTask();

const { items, getItems } = useInventory();

const globalStore = useGlobalStore();

const costOfMaterials = computed(() => {
    let cost = 0;
    if (task.materials.length > 0) {
        task.materials.forEach((mat) => {
            const it = globalStore.materials?.data?.filter((i) => {
                return i.id === mat.id;
            })[0];
            cost = +cost + +it.purchase_price * +mat.amount;
        });
        return cost.toFixed(2);
    }
    return "";
});

const totalCostCalculate = () => {
    totalCost.value = (+task.margin + +costOfMaterials.value).toFixed(2);
};

const setSetEditTaskValues = (t) => {
    document.getElementById("costOfMaterials").value = "";
    totalCost.value = "";
    setEditTaskValues(t);
    getAvailableWorkspaces(task.workshop_id);
};

customerUserTitle.value = "Customer";
employeesUserTitle.value = "Employee";

const userTitle = useAuthUserStore().user?.user_title;

onMounted(() => {
    getCustomers();
    getEmployees();
    getWorkshops();
    getItems();
    getTasks();
});
</script>
