<template>
    <div class="container my-4">
        <div
            v-if="
                auth.user?.user_title != 'Employee' &&
                auth.user?.user_title != 'Manager' &&
                auth.user?.user_title != 'Supervisor'
            "
            class="row my-4 gap-4 justify-content-center"
        >
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'inventory' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="InventoryImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Inventory</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'department' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="DepartmentImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="department"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Department</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'factory' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="FactoryImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="factory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Factory</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'users' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="UsersImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="users"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Users</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'workshop' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="WorkshopImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="workshops"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Workshops</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'userAccess' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="UserAccessImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="userAccess"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">User Access</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'reports' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="ReportsImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="reports"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Reports</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'task' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="TaskImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="task"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Task/Job</h4>
                    </div>
                </router-link>
            </div>
        </div>
        <div v-else class="row my-4 gap-4 justify-content-center">
            <div
                v-if="auth.user?.user_title !== 'Employee'"
                class="card col-md-3"
                style="width: 16rem"
            >
                <router-link
                    :to="{ name: 'reports' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="ReportsImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="reports"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Reports</h4>
                    </div>
                </router-link>
            </div>
            <div
                v-if="auth.user?.user_title === 'Employee'"
                class="card col-md-3"
                style="width: 16rem"
            >
                <router-link
                    :to="{ name: 'task' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="TaskImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="task"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">My Tasks/Jobs</h4>
                    </div>
                </router-link>
            </div>
            <div
                v-if="hasAccess('TASK_CRUD')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <router-link
                    :to="{ name: 'task' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="TaskImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="task"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Task/Job</h4>
                    </div>
                </router-link>
            </div>

            <div
                v-if="hasAccess('ITEM_CRUD')"
                class="card col-md-3"
                style="width: 16rem"
            >
                <router-link
                    :to="{ name: 'inventory' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="InventoryImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="inventory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">Inventory</h4>
                    </div>
                </router-link>
            </div>

            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'department' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="DepartmentImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="department"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">My Department</h4>
                    </div>
                </router-link>
            </div>

            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'factory' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="FactoryImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="factory"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">My Factory</h4>
                    </div>
                </router-link>
            </div>
            <div class="card col-md-3" style="width: 16rem">
                <router-link
                    :to="{ name: 'workshop' }"
                    class="text-decoration-none"
                >
                    <img
                        :src="WorkshopImage"
                        style="width: 200px; height: 200px"
                        class="card-img-top"
                        alt="workshops"
                    />
                    <div class="card-body">
                        <h4 class="card-text text-center">My Workshop</h4>
                    </div>
                </router-link>
            </div>
        </div>
    </div>
</template>

<script setup>
import InventoryImage from "../../images/undraw_logistics.svg";
import DepartmentImage from "../../images/undraw_development.svg";
import FactoryImage from "../../images/undraw_factory.svg";
import UsersImage from "../../images/undraw_product_iteration.svg";
import WorkshopImage from "../../images/undraw_coffee_break_h3uu.svg";
import UserAccessImage from "../../images/undraw_secure_login_pdn4.svg";
import ReportsImage from "../../images/undraw_report_re_f5n5.svg";
import TaskImage from "../../images/undraw_mind_map_re_nlb6.svg";
import { useAuthUserStore } from "@/stores/authUserStore";
import useNotification from "@/composables/notification";
import { useGlobalStore } from "@/stores/globalStore";
import { onMounted } from "vue";

const auth = useAuthUserStore();

const hasAccess = (which_access) => {
    let ha = false;
    if (auth.reportAccess?.access_levels?.length > 0) {
        for (let i = 0; i < auth.reportAccess.access_levels?.length; i++) {
            const al = auth.reportAccess?.access_levels[i];
            if (al?.report?.title === which_access) {
                ha = al?.has_access === 1;
            }
        }
    }
    return ha;
};

const globalStore = useGlobalStore();

const { allUnreadNotifications, getAllUnreadNotifications } = useNotification();

globalStore.notificationCount = allUnreadNotifications.length;

onMounted(() => {
    getAllUnreadNotifications();
});
</script>
