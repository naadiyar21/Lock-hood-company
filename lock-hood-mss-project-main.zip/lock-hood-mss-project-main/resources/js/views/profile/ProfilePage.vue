<template>
    <div>
        <form class="row" @submit.prevent="update">
            <div class="d-flex justify-content-end">
                <div class="form-check form-switch">
                    <input
                        id="editProfile"
                        v-model="editProfile"
                        class="form-check-input"
                        type="checkbox"
                        role="switch"
                    />
                    <label class="form-check-label" for="editProfile"
                        >Edit Profile</label
                    >
                </div>
            </div>
            <div class="mb-3 col-md-6">
                <label class="form-label">First Name</label>
                <input
                    v-model="authUser.user.first_name"
                    :disabled="!editProfile"
                    type="text"
                    placeholder="First Name"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-md-6">
                <label class="form-label">Last Name</label>
                <input
                    v-model="authUser.user.last_name"
                    :disabled="!editProfile"
                    type="text"
                    placeholder="Last Name"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-md-6">
                <label class="form-label">Email</label>
                <input
                    v-model="authUser.user.email"
                    :disabled="!editProfile"
                    type="email"
                    placeholder="email@example.com"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-md-6">
                <label class="form-label">Phone</label>
                <input
                    v-model="authUser.user.phone"
                    :disabled="!editProfile"
                    type="text"
                    placeholder="Your Contact No"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-12">
                <label class="form-label">Address 1</label>
                <input
                    v-model="authUser.user.address1"
                    :disabled="!editProfile"
                    type="text"
                    placeholder="Address 1"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-12">
                <label class="form-label">Address 2</label>
                <input
                    v-model="authUser.user.address2"
                    :disabled="!editProfile"
                    type="text"
                    placeholder="Address 2"
                    class="form-control"
                />
            </div>
            <div class="mb-3 col-md-6">
                <label class="form-label">User Title</label>
                <select
                    v-model="authUser.user.user_title"
                    :disabled="authUser.user.user_title === 'admin'"
                    class="form-select"
                    aria-label="Default select example"
                    required
                >
                    <option selected>Open this select menu</option>
                    <option value="Manager">Manager</option>
                    <option value="Supervisor">Supervisor</option>
                    <option value="Employee">Employee</option>
                    <option value="Customer">Customer</option>
                </select>
            </div>
            <div class="mb-3 col-md-6">
                <label class="form-label">Joined Date</label>
                <input
                    v-model="authUser.user.joined_date"
                    :disabled="!editProfile"
                    type="date"
                    class="form-control"
                />
            </div>
            <div v-if="editProfile">
                <button class="btn btn-outline-primary float-end" type="submit">
                    Update
                </button>
            </div>
        </form>
    </div>
</template>

<script setup>
import { ref } from "vue";
import useAuth from "@/composables/auth";
import { useAuthUserStore } from "@/stores/authUserStore";

const authUser = useAuthUserStore();
const { editProfile, update } = useAuth();
</script>
