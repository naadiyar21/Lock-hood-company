<template>
    <div>
        <form class="row" @submit.prevent="updatePassword">
            <div class="d-flex justify-content-end">
                <div class="form-check form-switch">
                    <input
                        id="showPassword"
                        v-model="showPassword"
                        class="form-check-input"
                        type="checkbox"
                        role="switch"
                    />
                    <label class="form-check-label" for="showPassword"
                        >Show Password</label
                    >
                </div>
            </div>
            <div class="mb-3 col-md-4">
                <label class="form-label">Current Password</label>
                <input
                    v-model="changePassword.current_password"
                    :type="showPassword ? 'text' : 'password'"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-md-4">
                <label class="form-label">New Password</label>
                <input
                    v-model="changePassword.password"
                    :type="showPassword ? 'text' : 'password'"
                    class="form-control"
                    required
                />
            </div>
            <div class="mb-3 col-md-4">
                <label class="form-label">Confirm Password</label>
                <input
                    v-model="changePassword.password_confirmation"
                    :type="showPassword ? 'text' : 'password'"
                    class="form-control"
                    required
                />
            </div>
            <div>
                <button class="btn btn-outline-primary float-end" type="submit">
                    Change Password
                </button>
            </div>
        </form>
    </div>
</template>

<script setup>
import useAuth from "@/composables/auth";
import { useAuthUserStore } from "@/stores/authUserStore";

const authUser = useAuthUserStore();
const { changePassword, showPassword, updatePassword } = useAuth();
</script>
