<template>
    <div class="container my-4">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <router-link
                    class="nav-link"
                    exact-active-class="active"
                    :to="{ name: 'profile' }"
                >
                    Profile
                </router-link>
            </li>
            <li class="nav-item">
                <router-link
                    class="nav-link"
                    exact-active-class="active"
                    :to="{ name: 'changePassword' }"
                >
                    Change Password
                </router-link>
            </li>
        </ul>
        <div class="tab-content py-4">
            <div class="card p-3">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>
