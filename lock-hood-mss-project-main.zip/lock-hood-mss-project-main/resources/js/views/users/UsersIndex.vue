<template>
    <div class="container my-4">
        <ModalComponent
            ref="addUserModalRef"
            :title="'Add User'"
            :modal-id="'addUserModal'"
        >
            <template #body>
                <div class="row">
                    <div class="mb-3 col-md-6">
                        <label class="form-label">First Name</label>
                        <input
                            v-model="user.first_name"
                            type="text"
                            placeholder="First Name"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Last Name</label>
                        <input
                            v-model="user.last_name"
                            type="text"
                            placeholder="Last Name"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Email</label>
                        <input
                            v-model="user.email"
                            type="email"
                            placeholder="email@example.com"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Phone</label>
                        <input
                            v-model="user.phone"
                            type="text"
                            placeholder="Your Contact No"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-12">
                        <label class="form-label">Address 1</label>
                        <input
                            v-model="user.address1"
                            type="text"
                            placeholder="Address 1"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-12">
                        <label class="form-label">Address 2</label>
                        <input
                            v-model="user.address2"
                            type="text"
                            placeholder="Address 2"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">User Title</label>
                        <select
                            v-model="user.user_title"
                            class="form-select"
                            aria-label="Default select example"
                            :disabled="
                                (user.user_title[0] === 'C' &&
                                    user.user_title !== 'Customer') ||
                                user.user_title === 'admin'
                            "
                            required
                        >
                            <option selected>Open this select menu</option>
                            <option value="Manager">Manager</option>
                            <option value="Supervisor">Supervisor</option>
                            <option value="Employee">Employee</option>
                            <option value="Customer">Customer</option>
                        </select>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Joined Date</label>
                        <input
                            v-model="user.joined_date"
                            type="date"
                            class="form-control"
                            :disabled="user.user_title === 'Customer'"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Password</label>
                        <input
                            v-model="user.password"
                            type="password"
                            placeholder="Password"
                            class="form-control"
                            :disabled="user.user_title === 'Customer'"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Confirm Password</label>
                        <input
                            v-model="user.password_confirmation"
                            type="password"
                            placeholder="Confirm Password"
                            class="form-control"
                            :disabled="user.user_title === 'Customer'"
                        />
                    </div>
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    class="btn btn-outline-success"
                    type="button"
                    @click="addUser(addUserModalRef)"
                >
                    Add User
                </button>
            </template>
        </ModalComponent>

        <ModalComponent
            ref="deleteUserModalRef"
            :title="'Delete User'"
            :modal-id="'deleteUserModal'"
        >
            <template #body>
                <h5>Are you sure you want to delete this user?</h5>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-danger"
                    @click="deleteUser(deleteUserModalRef)"
                >
                    Delete User
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="blockUserModalRef"
            :title="'Block/Unblock User'"
            :modal-id="'blockUserModal'"
        >
            <template #body>
                <h5>Are you sure you want to change this user's status?</h5>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-warning"
                    @click="changeStatus(blockUserModalRef)"
                >
                    Change Status
                </button>
            </template>
        </ModalComponent>
        <ModalComponent
            ref="editUserModalRef"
            :title="'Edit User'"
            :modal-id="'editUserModal'"
        >
            <template #body>
                <div class="row">
                    <div class="mb-3 col-md-6">
                        <label class="form-label">First Name</label>
                        <input
                            v-model="user.first_name"
                            type="text"
                            placeholder="First Name"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Last Name</label>
                        <input
                            v-model="user.last_name"
                            type="text"
                            placeholder="Last Name"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Email</label>
                        <input
                            v-model="user.email"
                            type="email"
                            placeholder="email@example.com"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Phone</label>
                        <input
                            v-model="user.phone"
                            type="text"
                            placeholder="Your Contact No"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-12">
                        <label class="form-label">Address 1</label>
                        <input
                            v-model="user.address1"
                            type="text"
                            placeholder="Address 1"
                            class="form-control"
                            required
                        />
                    </div>
                    <div class="mb-3 col-12">
                        <label class="form-label">Address 2</label>
                        <input
                            v-model="user.address2"
                            type="text"
                            placeholder="Address 2"
                            class="form-control"
                        />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">User Title</label>
                        <select
                            v-model="user.user_title"
                            class="form-select"
                            aria-label="Default select example"
                            :disabled="
                                (user.user_title[0] === 'C' &&
                                    user.user_title !== 'Customer') ||
                                user.user_title === 'admin'
                            "
                            required
                        >
                            <option selected>Open this select menu</option>
                            <option value="Manager">Manager</option>
                            <option value="Supervisor">Supervisor</option>
                            <option value="Employee">Employee</option>
                            <option value="Customer">Customer</option>
                        </select>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Joined Date</label>
                        <input
                            v-model="user.joined_date"
                            type="date"
                            class="form-control"
                            :disabled="user.user_title === 'Customer'"
                        />
                    </div>
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
                <button
                    type="button"
                    class="btn btn-primary"
                    @click="editUser(editUserModalRef)"
                >
                    Edit User
                </button>
            </template>
        </ModalComponent>
        <div class="row">
            <div class="col-12 col-md-10">
                <div class="input-group mb-4">
                    <input
                        v-model="searchKeyword"
                        type="text"
                        class="form-control"
                        placeholder="Search"
                        @input="getUsers(null)"
                    />
                    <select
                        v-model="userTitle"
                        class="form-select"
                        @change="getUsers(null)"
                    >
                        <option selected value="">Select user title...</option>
                        <option value="Manager">Manger</option>
                        <option value="Supervisor">Supervisor</option>
                        <option value="C">CXOs</option>
                        <option value="Employee">Employees</option>
                        <option value="Customer">Customers</option>
                    </select>
                    <button class="btn btn-outline-success" @click="reset">
                        Reset
                    </button>
                </div>
            </div>
            <div class="col-12 col-md-2 mb-4">
                <div class="d-grid">
                    <button
                        class="btn btn-outline-primary"
                        @click="addUserModalRef.show()"
                    >
                        Add User
                    </button>
                </div>
            </div>
            <div class="col table-responsive">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Full name</th>
                            <th>Title</th>
                            <th>Joined Date</th>
                            <th>Address 1</th>
                            <th>Address 2</th>
                            <th>Phone</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="fUser in users?.data" :key="fUser.id">
                            <td>{{ fUser.id }}</td>
                            <td>
                                {{ fUser.first_name }} {{ fUser.last_name }}
                            </td>
                            <td>{{ fUser.user_title }}</td>
                            <td>{{ fUser.joined_date }}</td>
                            <td>{{ fUser.address1 }}</td>
                            <td>{{ fUser.address2 }}</td>
                            <td>{{ fUser.phone }}</td>
                            <td>
                                <div class="d-flex gap-2">
                                    <button
                                        class="btn btn-outline-primary btn-sm"
                                        @click="
                                            () => {
                                                user.id = fUser.id;
                                                user.first_name =
                                                    fUser.first_name;
                                                user.last_name =
                                                    fUser.last_name;
                                                user.phone = fUser.phone;
                                                user.email = fUser.email;
                                                user.user_title =
                                                    fUser.user_title;
                                                user.address1 = fUser.address1;
                                                user.address2 = fUser.address2;
                                                user.joined_date =
                                                    fUser.joined_date;
                                                user.status = fUser.status;
                                                editUserModalRef.show();
                                            }
                                        "
                                    >
                                        Edit
                                    </button>
                                    <button
                                        class="btn btn-sm"
                                        :class="{
                                            'btn-outline-warning':
                                                fUser.status === 1,
                                            'btn-outline-success':
                                                fUser.status === 0,
                                        }"
                                        @click="
                                            () => {
                                                user.id = fUser.id;
                                                blockUserModalRef.show();
                                            }
                                        "
                                    >
                                        {{
                                            fUser.status === 0
                                                ? "Unblock"
                                                : "Block"
                                        }}
                                    </button>
                                    <button
                                        class="btn btn-outline-danger btn-sm"
                                        @click="
                                            () => {
                                                user.id = fUser.id;
                                                deleteUserModalRef.show();
                                            }
                                        "
                                    >
                                        Delete
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <PaginatorComponent :items="users" @get-items="getUsers" />
        </div>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import PaginatorComponent from "@/components/PaginatorComponent.vue";
import useUsers from "@/composables/users";
import { onMounted, ref } from "vue";

const {
    users,
    user,
    searchKeyword,
    userTitle,
    getUsers,
    editUser,
    deleteUser,
    changeStatus,
    addUser,
} = useUsers();

const editUserModalRef = ref();
const deleteUserModalRef = ref();
const blockUserModalRef = ref();
const addUserModalRef = ref();

const reset = () => {
    searchKeyword.value = null;
    userTitle.value = null;
    getUsers();
};

onMounted(async () => {
    await getUsers();
});
</script>
