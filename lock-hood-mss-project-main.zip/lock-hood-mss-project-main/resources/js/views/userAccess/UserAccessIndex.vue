<template>
    <div class="container my-4">
        <ModalComponent
            ref="reportAccessModalRef"
            :modal-id="'reportAccessModal'"
            :title="'Report Access'"
        >
            <template #body>
                <div class="table-responsive mt-4">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Report</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="r in actualReports" :key="r?.id">
                                <td>{{ r?.id }}</td>
                                <td>
                                    {{ r?.description }}
                                </td>
                                <td>
                                    <button
                                        v-if="hasAccess(selectedUser, r.title)"
                                        class="btn btn-outline-danger btn-sm"
                                        @click="
                                            () => {
                                                changeAccess(
                                                    selectedUser.id,
                                                    false,
                                                    r.title
                                                ).then(async () => {
                                                    await getManagersAndSupervisorsOnly(
                                                        null
                                                    );
                                                    selectedUser =
                                                        users?.data?.filter(
                                                            (u) => {
                                                                return (
                                                                    u?.id ===
                                                                    selectedUser?.id
                                                                );
                                                            }
                                                        )[0];
                                                });
                                            }
                                        "
                                    >
                                        Revoke
                                    </button>
                                    <button
                                        v-else
                                        class="btn btn-outline-primary btn-sm"
                                        @click="
                                            () => {
                                                changeAccess(
                                                    selectedUser.id,
                                                    true,
                                                    r.title
                                                ).then(async () => {
                                                    await getManagersAndSupervisorsOnly(
                                                        null
                                                    );
                                                    selectedUser =
                                                        users?.data?.filter(
                                                            (u) => {
                                                                return (
                                                                    u?.id ===
                                                                    selectedUser?.id
                                                                );
                                                            }
                                                        )[0];
                                                });
                                            }
                                        "
                                    >
                                        Approve
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </template>
            <template #footer>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>
            </template>
        </ModalComponent>

        <ul id="myTab" class="nav nav-tabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button
                    id="task-crud"
                    class="nav-link active"
                    data-bs-toggle="tab"
                    data-bs-target="#task-crud-pane-tab"
                    type="button"
                    role="tab"
                    aria-controls="task-crud-pane-tab"
                    aria-selected="true"
                >
                    Task CRUD
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button
                    id="inventory-crud"
                    class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#inventory-crud-pane-tab"
                    type="button"
                    role="tab"
                    aria-controls="inventory-crud-pane-tab"
                    aria-selected="true"
                >
                    Inventory CRUD
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button
                    id="item-reorder-notification"
                    class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#item-reorder-notification-pane-tab"
                    type="button"
                    role="tab"
                    aria-controls="item-reorder-notification-pane-tab"
                    aria-selected="true"
                >
                    Item Reorder Notification
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button
                    id="report-access"
                    class="nav-link"
                    data-bs-toggle="tab"
                    data-bs-target="#report-access-tab-pane"
                    type="button"
                    role="tab"
                    aria-controls="report-access-tab-pane"
                    aria-selected="false"
                >
                    Report Access
                </button>
            </li>
        </ul>
        <div id="myTabContent" class="tab-content">
            <div
                id="task-crud-pane-tab"
                class="tab-pane mb-4 fade show active"
                role="tabpanel"
                aria-labelledby="task-crud"
                tabindex="0"
            >
                <div class="p-2 mt-2">
                    <h5>Who has access to create, edit and delete task?</h5>
                    <input
                        v-model="searchKeyword"
                        type="text"
                        class="form-control"
                        placeholder="Search"
                        @input="getManagersAndSupervisorsOnly(null)"
                    />
                    <div class="col table-responsive mt-4">
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full name</th>
                                    <th>Email</th>
                                    <th>Title</th>
                                    <th>Joined Date</th>
                                    <th>Address 1</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="fUser in users?.data"
                                    :key="fUser.id"
                                >
                                    <td>{{ fUser.id }}</td>
                                    <td>
                                        {{ fUser.first_name }}
                                        {{ fUser.last_name }}
                                    </td>
                                    <td>{{ fUser.email }}</td>
                                    <td>{{ fUser.user_title }}</td>
                                    <td>{{ fUser.joined_date }}</td>
                                    <td>{{ fUser.address1 }}</td>
                                    <td>{{ fUser.phone }}</td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <button
                                                v-if="
                                                    hasAccess(
                                                        fUser,
                                                        'TASK_CRUD'
                                                    )
                                                "
                                                class="btn btn-outline-danger btn-sm"
                                                @click="
                                                    () => {
                                                        changeAccess(
                                                            fUser.id,
                                                            false,
                                                            'TASK_CRUD'
                                                        ).then(() => {
                                                            getManagersAndSupervisorsOnly(
                                                                null
                                                            );
                                                        });
                                                    }
                                                "
                                            >
                                                Cancel
                                            </button>
                                            <button
                                                v-else
                                                class="btn btn-outline-primary btn-sm"
                                                @click="
                                                    () => {
                                                        changeAccess(
                                                            fUser.id,
                                                            true,
                                                            'TASK_CRUD'
                                                        ).then(() => {
                                                            getManagersAndSupervisorsOnly(
                                                                null
                                                            );
                                                        });
                                                    }
                                                "
                                            >
                                                Approve
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <PaginatorComponent
                        :items="users"
                        @get-items="getManagersAndSupervisorsOnly"
                    />
                </div>
            </div>
            <div
                id="inventory-crud-pane-tab"
                class="tab-pane fade"
                role="tabpanel"
                aria-labelledby="inventory-crud"
                tabindex="0"
            >
                <div class="p-2 mt-2">
                    <h5>
                        Who has access to create, edit and delete inventory
                        item?
                    </h5>
                    <input
                        v-model="searchKeyword"
                        type="text"
                        class="form-control"
                        placeholder="Search"
                        @input="getManagersAndSupervisorsOnly(null)"
                    />
                    <div class="col table-responsive mt-4">
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full name</th>
                                    <th>Email</th>
                                    <th>Title</th>
                                    <th>Joined Date</th>
                                    <th>Address 1</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="fUser in users?.data"
                                    :key="fUser.id"
                                >
                                    <td>{{ fUser.id }}</td>
                                    <td>
                                        {{ fUser.first_name }}
                                        {{ fUser.last_name }}
                                    </td>
                                    <td>{{ fUser.email }}</td>
                                    <td>{{ fUser.user_title }}</td>
                                    <td>{{ fUser.joined_date }}</td>
                                    <td>{{ fUser.address1 }}</td>
                                    <td>{{ fUser.phone }}</td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <button
                                                v-if="
                                                    hasAccess(
                                                        fUser,
                                                        'ITEM_CRUD'
                                                    )
                                                "
                                                class="btn btn-outline-danger btn-sm"
                                                @click="
                                                    () => {
                                                        changeAccess(
                                                            fUser.id,
                                                            false,
                                                            'ITEM_CRUD'
                                                        ).then(() => {
                                                            getManagersAndSupervisorsOnly(
                                                                null
                                                            );
                                                        });
                                                    }
                                                "
                                            >
                                                Cancel
                                            </button>
                                            <button
                                                v-else
                                                class="btn btn-outline-primary btn-sm"
                                                @click="
                                                    () => {
                                                        changeAccess(
                                                            fUser.id,
                                                            true,
                                                            'ITEM_CRUD'
                                                        ).then(() => {
                                                            getManagersAndSupervisorsOnly(
                                                                null
                                                            );
                                                        });
                                                    }
                                                "
                                            >
                                                Approve
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <PaginatorComponent
                        :items="users"
                        @get-items="getManagersAndSupervisorsOnly"
                    />
                </div>
            </div>
            <div
                id="item-reorder-notification-pane-tab"
                class="tab-pane fade"
                role="tabpanel"
                aria-labelledby="item-reorder-notification"
                tabindex="0"
            >
                <div class="p-2 mt-2">
                    <h5>
                        Who should receive a notification when an item's reorder
                        level exceeds?
                    </h5>
                    <input
                        v-model="searchKeyword"
                        type="text"
                        class="form-control"
                        placeholder="Search"
                        @input="getManagersAndSupervisorsOnly(null)"
                    />
                    <div class="col table-responsive mt-4">
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full name</th>
                                    <th>Email</th>
                                    <th>Title</th>
                                    <th>Joined Date</th>
                                    <th>Address 1</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="fUser in users?.data"
                                    :key="fUser.id"
                                >
                                    <td>{{ fUser.id }}</td>
                                    <td>
                                        {{ fUser.first_name }}
                                        {{ fUser.last_name }}
                                    </td>
                                    <td>{{ fUser.email }}</td>
                                    <td>{{ fUser.user_title }}</td>
                                    <td>{{ fUser.joined_date }}</td>
                                    <td>{{ fUser.address1 }}</td>
                                    <td>{{ fUser.phone }}</td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <button
                                                v-if="
                                                    hasNotificationAccess(
                                                        fUser,
                                                        'ITEM_REORDER'
                                                    )
                                                "
                                                class="btn btn-outline-danger btn-sm"
                                                @click="
                                                    () => {
                                                        changeNotificationAccess(
                                                            fUser.id,
                                                            false,
                                                            'ITEM_REORDER'
                                                        ).then(() => {
                                                            getManagersAndSupervisorsOnly(
                                                                null
                                                            );
                                                        });
                                                    }
                                                "
                                            >
                                                Hide
                                            </button>
                                            <button
                                                v-else
                                                class="btn btn-outline-primary btn-sm"
                                                @click="
                                                    () => {
                                                        changeNotificationAccess(
                                                            fUser.id,
                                                            true,
                                                            'ITEM_REORDER'
                                                        ).then(() => {
                                                            getManagersAndSupervisorsOnly(
                                                                null
                                                            );
                                                        });
                                                    }
                                                "
                                            >
                                                Notify
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <PaginatorComponent
                        :items="users"
                        @get-items="getManagersAndSupervisorsOnly"
                    />
                </div>
            </div>
            <div
                id="report-access-tab-pane"
                class="tab-pane fade"
                role="tabpanel"
                aria-labelledby="report-access"
                tabindex="0"
            >
                <div class="p-2 mt-2">
                    <h5>Who has which report access?</h5>
                    <input
                        v-model="searchKeyword"
                        type="text"
                        class="form-control"
                        placeholder="Search"
                        @input="getManagersAndSupervisorsOnly(null)"
                    />
                    <div class="col table-responsive mt-4">
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full name</th>
                                    <th>Email</th>
                                    <th>Title</th>
                                    <th>Joined Date</th>
                                    <th>Address 1</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-for="fUser in users?.data"
                                    :key="fUser.id"
                                >
                                    <td>{{ fUser.id }}</td>
                                    <td>
                                        {{ fUser.first_name }}
                                        {{ fUser.last_name }}
                                    </td>
                                    <td>{{ fUser.email }}</td>
                                    <td>{{ fUser.user_title }}</td>
                                    <td>{{ fUser.joined_date }}</td>
                                    <td>{{ fUser.address1 }}</td>
                                    <td>{{ fUser.phone }}</td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <button
                                                class="btn btn-outline-primary btn-sm"
                                                @click="
                                                    () => {
                                                        selectedUser = fUser;
                                                        reportAccessModalRef.show();
                                                    }
                                                "
                                            >
                                                Edit Report Access
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <PaginatorComponent
                        :items="users"
                        @get-items="getManagersAndSupervisorsOnly"
                    />
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import ModalComponent from "@/components/ModalComponent.vue";
import PaginatorComponent from "@/components/PaginatorComponent.vue";
import useNotification from "@/composables/notification";
import useReportAccess from "@/composables/reportAccess";
import useUsers from "@/composables/users";
import { onMounted, ref, computed } from "vue";

const { users, searchKeyword, getManagersAndSupervisorsOnly } = useUsers();
const { reports, changeAccess, getAvailableReports } = useReportAccess();
const { changeAccess: changeNotificationAccess } = useNotification();
const reportAccessModalRef = ref();
const selectedUser = ref(null);

const hasAccess = (user, which_access) => {
    let ha = false;
    if (user?.access_levels?.length > 0) {
        user?.access_levels?.forEach((al) => {
            if (al?.has_access) {
                if (al?.report != null) {
                    if (al?.report?.title === which_access) ha = true;
                }
            }
        });
    }
    return ha;
};

const hasNotificationAccess = (user, which_notification) => {
    let ha = false;
    if (user.user_notifications?.length > 0) {
        user?.user_notifications?.forEach((al) => {
            if (which_notification === al.which_notification)
                ha = al.notify_or_not;
        });
    }
    return ha;
};

const actualReports = computed(() => {
    if (reports.value?.length > 0) {
        return reports.value?.filter((r) => {
            const re = r.title.split("_");
            return re[re.length - 1] === "REPORT";
        });
    }
    return [];
});

onMounted(async () => {
    await getManagersAndSupervisorsOnly();
    await getAvailableReports();
});
</script>
