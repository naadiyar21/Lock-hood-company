import { defineStore } from "pinia";

export const useUsersStore = defineStore({
    id: "users-store",
    state: () => ({}),
    action: {},
});
