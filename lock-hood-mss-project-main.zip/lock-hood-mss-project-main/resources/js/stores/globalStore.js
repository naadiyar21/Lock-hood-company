import { getErrorsForNotification } from "@/helpers/formatter";
import { defineStore } from "pinia";

export const useGlobalStore = defineStore({
    id: "global-store",
    state: () => ({
        modal: null,
        primaryModal: null,
        status: "",
        heading: "",
        messages: [],
        editingItem: {},
        notificationCount: 0,
        materials: [],
    }),
    actions: {
        hide() {
            this.modal?.hide();
            if (this.primaryModal != null && this.status >= 400) {
                this.primaryModal?.show();
            }
            this.status = "";
            this.heading = "";
            this.messages = [];
        },
        show() {
            if (this.primaryModal != null) {
                this.primaryModal?.hide();
            }
            this.modal?.show();
        },
        showError(error) {
            ({
                title: this.heading,
                text: this.messages,
                status: this.status,
            } = getErrorsForNotification(error.response));
            this.show();
        },
        showSuccess(heading, message, status = 200) {
            this.heading = heading;
            this.messages = message;
            this.status = status;
            this.show();
        },
    },
});
