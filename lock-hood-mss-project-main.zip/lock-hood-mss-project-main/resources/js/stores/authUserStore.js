import { defineStore } from "pinia";

export const useAuthUserStore = defineStore({
    id: "auth-user-store",
    state: () => ({
        user: JSON.parse(localStorage.getItem("user")),
        returnURL: "",
        reportAccess: JSON.parse(localStorage.getItem("reportAccess")),
    }),
    getters: {
        getAuthUser: (state) => state.user,
        getReportAccess: (state) => state.reportAccess,
    },
    actions: {
        setUser(user) {
            this.user = user;
            localStorage.setItem("user", JSON.stringify(user));
        },
        removeUser() {
            this.user = null;
            localStorage.removeItem("user");
        },
        setReportAccess(reportAccess) {
            this.reportAccess = reportAccess;
            localStorage.setItem("reportAccess", JSON.stringify(reportAccess));
        },
        removeReportAccess() {
            this.reportAccess = null;
            localStorage.removeItem("reportAccess");
        },
    },
});
