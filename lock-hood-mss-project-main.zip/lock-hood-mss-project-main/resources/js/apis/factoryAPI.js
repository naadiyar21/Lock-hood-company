import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/factory",
});

export default {
    async getFactories() {
        return instance.get("/");
    },

    async addFactory(factory) {
        return instance.post("/", factory);
    },

    async editFactory(factory) {
        return instance.put("/", factory);
    },

    async deleteFactory(factory) {
        return instance.post("/", factory);
    },
};
