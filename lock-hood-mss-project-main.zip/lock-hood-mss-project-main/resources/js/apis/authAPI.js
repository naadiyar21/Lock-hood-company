import axios from "axios";

export default {
    async getCSRF() {
        return axios.get("/sanctum/csrf-cookie");
    },
    async login(credential) {
        await this.getCSRF();
        return axios.post("/login", credential);
    },
    async getUser() {
        return axios.get("/api/user");
    },
    async logout() {
        return axios.post("/logout");
    },
    async register(data) {
        await this.getCSRF();
        return axios.post("/register", data);
    },
    async updateProfile(data) {
        return axios.put("/user/profile-information", data);
    },
    async updatePassword(passwrods) {
        return axios.put("/user/password", passwrods);
    },
};
