import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/workshop",
});

export default {
    async getWorkshops() {
        return instance.get("/");
    },
    async addWorkshop(workshop) {
        return instance.post("/", workshop);
    },
    async editWorkshop(workshop) {
        return instance.put("/", workshop);
    },
    async deleteWorkshop(id) {
        return instance.delete(`/${id}`);
    },
};
