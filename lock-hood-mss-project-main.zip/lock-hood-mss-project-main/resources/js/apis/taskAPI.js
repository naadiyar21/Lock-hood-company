import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/task",
});

export default {
    async addTask(task) {
        return instance.post("/", task);
    },
    async getTasks(page) {
        return instance.get(`/?page=${page}`);
    },
    async updateTask(task) {
        return instance.put("/", task);
    },
    async deleteTask(taskId) {
        return instance.post("/", {
            id: taskId,
            _method: "delete",
        });
    },
    async doneTask(taskId) {
        return instance.post("/task-done", {
            taskId,
        });
    },
};
