import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/report-access",
});

export default {
    async changeAccess(access) {
        return instance.post("/task-access", access);
    },
    async getReportAccess() {
        return instance.get("/");
    },
};
