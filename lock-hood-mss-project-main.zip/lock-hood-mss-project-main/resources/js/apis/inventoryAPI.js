import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/inventory",
});

export default {
    async addInventory(item) {
        return instance.post("/", item);
    },

    async getItems(page, per_page = 10) {
        return instance.get(`/?page=${page}&per_page=${per_page}`);
    },

    async updateItem(item) {
        return instance.put("/", item);
    },

    async deleteItem(id) {
        return instance.post("/", id);
    },

    async purchaseItem(item) {
        return instance.post("/purchase-item", item);
    },
};
