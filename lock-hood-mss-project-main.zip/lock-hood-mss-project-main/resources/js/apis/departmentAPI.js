import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/department",
});

export default {
    async getDepartments() {
        return instance.get("/");
    },

    async addDepartment(department) {
        return instance.post("/", department);
    },

    async editDepartment(department) {
        return instance.put("/", department);
    },

    async deleteDepartment(department) {
        return instance.post("/", department);
    },
};
