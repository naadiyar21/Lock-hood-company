import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/notifications",
});

export default {
    async getAllowedNotifications() {
        return instance.get("/allowed-notifications");
    },
    async changeNotificationAccess(access) {
        return instance.post("/notification-access", access);
    },
    async getAllNotifications() {
        return instance.get("/all-notifications");
    },
    async getAllUnreadNotifications() {
        return instance.get("/unread-notifications");
    },
    async markAsRead(id) {
        return instance.post("/mark-as-read", { id });
    },
};
