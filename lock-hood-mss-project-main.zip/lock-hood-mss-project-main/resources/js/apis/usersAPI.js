import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/users",
});

export default {
    async getUsers(user_title, searchKeyword, page) {
        return instance.get(`/${user_title}/${searchKeyword}/?page=${page}`);
    },
    async updateUser(user) {
        return instance.put("/", user);
    },
    async changeStatus(id) {
        return instance.post(`/change-status/${id}`);
    },
    async deleteUser(id) {
        return instance.delete(`/${id}`);
    },
    async addUser(user) {
        return instance.post("/add-user", user);
    },
    async getManagersAndSupervisorsOnly(searchKeyword, page) {
        return instance.get(
            `/get-managers-and-supervisors-only/${searchKeyword}/?page=${page}`
        );
    },
};
