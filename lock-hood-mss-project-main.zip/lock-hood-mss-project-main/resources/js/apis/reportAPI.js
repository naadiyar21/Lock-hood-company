import axios from "axios";

const instance = axios.create({
    baseURL: "/web-api/report",
});

export default {
    async incomeReport(from, to) {
        return instance.get(`/income-report/${from}/${to}`);
    },
    async getAvailableReports() {
        return instance.get("/available-reports");
    },
    async getItemsBelowReorderLevel() {
        return instance.get("/items-below-reorder-level");
    },
    async getTaskKPIs() {
        return instance.get("/task-kpi");
    },
    async getMostUsedRawMaterials() {
        return instance.get("/most-used-raw-materials");
    },
    async getTotalIncomeOutgoingOfAOrder() {
        return instance.get("/total-income-outgoing-of-a-order");
    },
    async getMostWorkedEmployees() {
        return instance.get("/get-most-worked-employees");
    },
};
