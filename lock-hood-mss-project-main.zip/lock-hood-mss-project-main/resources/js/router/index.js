import { createRouter, createWebHistory } from "vue-router";
import { useAuthUserStore } from "@/stores/authUserStore";

const login = () => import("@/views/auth/LoginIndex.vue");
const register = () => import("@/views/auth/RegisterIndex.vue");
const dashboard = () => import("@/views/DashboardIndex.vue");
const profile = () => import("@/views/profile/ProfileIndex.vue");
const profilePage = () => import("@/views/profile/ProfilePage.vue");
const changePasswordPage = () =>
    import("@/views/profile/ChangePasswordPage.vue");
const inventory = () => import("@/views/inventory/InventoryIndex.vue");
const department = () => import("@/views/department/DepartmentIndex.vue");
const factory = () => import("@/views/factory/FactoryIndex.vue");
const users = () => import("@/views/users/UsersIndex.vue");
const Workshop = () => import("@/views/workshop/WorkshopIndex.vue");
const UserAccess = () => import("@/views/userAccess/UserAccessIndex.vue");
const Reports = () => import("@/views/reports/ReportsIndex.vue");
const Task = () => import("@/views/task/TaskIndex.vue");
const Notifications = () => import("@/views/NotificationsIndex.vue");

const router = createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: "/",
            name: "dashboard",
            component: dashboard,
            meta: {
                heading: "Dashboard",
            },
        },
        {
            path: "/login",
            name: "login",
            component: login,
        },
        {
            path: "/register",
            name: "register",
            component: register,
        },
        {
            path: "/profile",
            redirect: { name: "profile" },
            component: profile,
            meta: {
                heading: "Profile",
            },
            children: [
                {
                    path: "",
                    name: "profile",
                    component: profilePage,
                },
                {
                    path: "change-password",
                    name: "changePassword",
                    component: changePasswordPage,
                },
            ],
        },
        {
            path: "/inventory",
            name: "inventory",
            component: inventory,
            meta: {
                heading: "Inventory",
            },
        },
        {
            path: "/department",
            name: "department",
            component: department,
            meta: {
                heading: "Department",
            },
        },
        {
            path: "/factory",
            name: "factory",
            component: factory,
            meta: {
                heading: "Factory",
            },
        },
        {
            path: "/users",
            name: "users",
            component: users,
            meta: {
                heading: "Users",
            },
        },
        {
            path: "/workshop",
            name: "workshop",
            component: Workshop,
            meta: {
                heading: "Workshops",
            },
        },
        {
            path: "/user-access",
            name: "userAccess",
            component: UserAccess,
            meta: {
                heading: "User Access",
            },
        },
        {
            path: "/reports",
            name: "reports",
            component: Reports,
            meta: {
                heading: "Reports",
            },
        },
        {
            path: "/task",
            name: "task",
            component: Task,
            meta: {
                heading: "Task/Job",
            },
        },
        {
            path: "/notifications",
            name: "notifications",
            component: Notifications,
            meta: {
                heading: "Notifications",
            },
        },
    ],
});

router.beforeEach(async (to) => {
    const publicPages = ["/login", "/register"];
    const authRequired = !publicPages.includes(to.path);
    const auth = useAuthUserStore();

    if (authRequired && !auth.user) {
        auth.returnURL = to.fullPath;
        return "/login";
    }
});

export default router;
