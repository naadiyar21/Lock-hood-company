import notificationAPI from "@/apis/notificationAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { ref } from "vue";

export default function useNotification() {
    const globalStore = useGlobalStore();
    const allNotifications = ref([]);
    const allUnreadNotifications = ref([]);

    const changeAccess = async (user_id, notify_or_not, which_notification) => {
        try {
            await notificationAPI.changeNotificationAccess({
                user_id,
                notify_or_not,
                which_notification,
            });
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getAllNotifications = async () => {
        try {
            allNotifications.value = await (
                await notificationAPI.getAllNotifications()
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getAllUnreadNotifications = async () => {
        try {
            allUnreadNotifications.value = await (
                await notificationAPI.getAllUnreadNotifications()
            ).data;
            globalStore.notificationCount = allUnreadNotifications.value.length;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const markAsRead = async (id = null) => {
        try {
            notificationAPI.markAsRead(id);
            await getAllUnreadNotifications();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    return {
        allNotifications,
        allUnreadNotifications,
        getAllNotifications,
        getAllUnreadNotifications,
        changeAccess,
        markAsRead,
    };
}
