import departmentAPI from "@/apis/departmentAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { reactive, ref } from "vue";

export default function useDepartment() {
    const globalStore = useGlobalStore();
    const department = reactive({
        id: "",
        manager_id: "",
        factory_id: "",
        title: "",
    });
    const departments = ref();

    const getDepartments = async () => {
        try {
            departments.value = await (
                await departmentAPI.getDepartments()
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const addDepartment = async (addDepartmentModal) => {
        globalStore.primaryModal = addDepartmentModal;
        try {
            await departmentAPI.addDepartment(department);
            globalStore.showSuccess("Done!", [
                "Successfully created a department!",
            ]);
            addDepartmentModal.hide();
            clear();
            await getDepartments();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const editDepartment = async (editDepartmentModal) => {
        globalStore.primaryModal = editDepartmentModal;
        try {
            await departmentAPI.editDepartment(department);
            globalStore.showSuccess("Done!", [
                "Successfully department updated!",
            ]);
            editDepartmentModal.hide();
            clear();
            await getDepartments();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const deleteDepartment = async (deleteDepartmentModal) => {
        globalStore.primaryModal = deleteDepartmentModal;
        try {
            await departmentAPI.deleteDepartment({
                id: department.id,
                _method: "delete",
            });
            globalStore.showSuccess("Done!", [
                "Successfully department deleted!",
            ]);
            clear();
            deleteDepartmentModal.hide();
            await getDepartments();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const clear = () => {
        department.id = "";
        department.manager_id = "";
        department.title = "";
        department.factory_id = "";
    };

    return {
        department,
        departments,
        getDepartments,
        addDepartment,
        editDepartment,
        deleteDepartment,
    };
}
