import workshopAPI from "@/apis/workshopAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { reactive, ref } from "vue";

export default function useWorkshop() {
    const globalStore = useGlobalStore();
    const workshop = reactive({
        id: "",
        supervisor_id: "",
        department_id: "",
        title: "",
        total_space: "",
    });
    const workshops = ref();
    const avaiableWorkspaces = ref(0);

    const getWorkshops = async () => {
        try {
            workshops.value = await (await workshopAPI.getWorkshops()).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const addWorkshop = async (addWorkshopModal) => {
        globalStore.primaryModal = addWorkshopModal;
        try {
            await workshopAPI.addWorkshop(workshop);
            globalStore.showSuccess("Done!", [
                "Successfully created a workshop!",
            ]);
            addWorkshopModal.hide();
            clear();
            await getWorkshops();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const editWorkshop = async (editWorkshopModal) => {
        globalStore.primaryModal = editWorkshopModal;
        try {
            await workshopAPI.editWorkshop(workshop);
            globalStore.showSuccess("Done!", [
                "Successfully workshop updated!",
            ]);
            editWorkshopModal.hide();
            clear();
            await getWorkshops();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const deleteWorkshop = async (deleteWorkshopModal) => {
        globalStore.primaryModal = deleteWorkshopModal;
        try {
            await workshopAPI.deleteWorkshop(workshop.id);
            globalStore.showSuccess("Done!", [
                "Successfully workshop deleted!",
            ]);
            clear();
            deleteWorkshopModal.hide();
            await getWorkshops();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const clear = () => {
        workshop.id = "";
        workshop.supervisor_id = "";
        workshop.title = "";
        workshop.department_id = "";
        workshop.total_space = "";
    };

    const getAvailableWorkspaces = (workers_id) => {
        if (workers_id != "") {
            const workshop = workshops.value.filter((w) => {
                return w.id === workers_id;
            })[0];
            let used_space = 0;
            for (let i = 0; i < workshop.tasks.length; i++) {
                const task = workshop.tasks[i];
                if (!task.is_done)
                    used_space =
                        +used_space + +task.working_line.required_space;
            }
            avaiableWorkspaces.value = +workshop.total_space - +used_space;
        }
    };

    return {
        workshop,
        workshops,
        avaiableWorkspaces,
        getAvailableWorkspaces,
        getWorkshops,
        addWorkshop,
        editWorkshop,
        deleteWorkshop,
    };
}
