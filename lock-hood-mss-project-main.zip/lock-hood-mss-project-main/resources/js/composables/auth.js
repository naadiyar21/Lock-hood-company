import { ref, reactive } from "vue";
import authAPI from "@/apis/authAPI";
import { getErrorsForNotification } from "@/helpers/formatter";
import { useAuthUserStore } from "@/stores/authUserStore";
import { useGlobalStore } from "@/stores/globalStore";
import router from "@/router";
import reportAccessAPI from "@/apis/reportAccessAPI";

export default function useAuth() {
    const regUser = reactive({
        first_name: "",
        last_name: "",
        email: "",
        phone: "",
        address1: "",
        address2: "",
        password: "",
        password_confirmation: "",
        joined_date: "",
        user_title: "",
    });

    const loginCredentials = reactive({
        email: "",
        password: "",
    });

    const changePassword = reactive({
        current_password: "",
        password: "",
        password_confirmation: "",
    });

    const editProfile = ref(false);
    const showPassword = ref(false);

    const globalStore = useGlobalStore();
    const authStore = useAuthUserStore();

    const register = async () => {
        try {
            await authAPI.register(regUser);
            clear();
            globalStore.showSuccess("Done!", [
                "Successfully new user registered! please login to the system!",
            ]);
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const login = async () => {
        try {
            await authAPI.login(loginCredentials);
            const user = await (await authAPI.getUser()).data;
            const reportAccess = await (
                await reportAccessAPI.getReportAccess()
            ).data;
            authStore.setUser(user);
            authStore.setReportAccess(reportAccess);
            router.push(authStore.returnURL || "/");
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const logout = async () => {
        try {
            await authAPI.logout();
            authStore.removeUser();
            router.push({ name: "login" });
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const update = async () => {
        try {
            await authAPI.updateProfile(authStore.user);
            const user = await authAPI.getUser();
            authStore.setUser(user.data);
            editProfile.value = false;
            globalStore.showSuccess("Done!", [
                "Successfully user details updated!",
            ]);
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const updatePassword = async () => {
        try {
            await authAPI.updatePassword(changePassword);
            clear();
            globalStore.showSuccess("Done!", [
                "Successfully password changed!",
            ]);
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const clear = () => {
        regUser.first_name = "";
        regUser.last_name = "";
        regUser.email = "";
        regUser.phone = "";
        regUser.address1 = "";
        regUser.address2 = "";
        regUser.password = "";
        regUser.password_confirmation = "";
        regUser.joined_date = "";
        regUser.user_title = "";
        showPassword.value = false;
        changePassword.current_password = "";
        changePassword.password = "";
        changePassword.password_confirmation = "";
    };

    return {
        regUser,
        loginCredentials,
        editProfile,
        changePassword,
        showPassword,
        register,
        updatePassword,
        login,
        logout,
        update,
    };
}
