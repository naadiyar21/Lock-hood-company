import reportAccessAPI from "@/apis/reportAccessAPI";
import reportAPI from "@/apis/reportAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { ref } from "vue";

export default function useReportAccess() {
    const globalStore = useGlobalStore();
    const reports = ref([]);

    const changeAccess = async (user_id, has_access, which_access) => {
        try {
            await reportAccessAPI.changeAccess({
                user_id,
                has_access,
                which_access,
            });
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getAvailableReports = async () => {
        try {
            reports.value = await (await reportAPI.getAvailableReports()).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    return {
        changeAccess,
        reports,
        getAvailableReports,
    };
}
