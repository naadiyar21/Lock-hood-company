import { reactive, ref } from "vue";
import inventoryAPI from "@/apis/inventoryAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { getPage } from "@/helpers/getPage";

export default function useInventory() {
    const inventoryItem = reactive({
        id: "",
        item: "",
        quantity: "",
        stock: "",
        reorder_level: "",
        purchase_price: "",
        unit_of_measurement: "",
        purchase_quantity: "",
    });

    const items = ref();
    const globalStore = useGlobalStore();

    const addItem = async (addItemModalRef) => {
        globalStore.primaryModal = addItemModalRef;
        try {
            await inventoryAPI.addInventory(inventoryItem);
            globalStore.showSuccess("Done!", [
                "Successfully new item added to the inventory!",
            ]);
            clear();
            getItems();
            addItemModalRef.hide();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getItems = async (url) => {
        const page = getPage(url);
        try {
            items.value = await (await inventoryAPI.getItems(page)).data;
            globalStore.materials = await (
                await inventoryAPI.getItems(1, items.value?.total)
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const editItem = async (editItemRef) => {
        globalStore.primaryModal = editItemRef;
        try {
            await inventoryAPI.updateItem(inventoryItem);
            globalStore.showSuccess("Done!", ["Successfully item updated!"]);
            clear();
            getItems();
            editItemRef.hide();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const deleteItem = async (deleteItemRef) => {
        globalStore.primaryModal = deleteItemRef;
        try {
            await inventoryAPI.deleteItem({
                id: inventoryItem.id,
                _method: "delete",
            });
            globalStore.showSuccess("Done!", ["Successfully item deleted!"]);
            clear();
            getItems();
            deleteItemRef.hide();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const purchaseItem = async (purchaseItemRef) => {
        globalStore.primaryModal = purchaseItemRef;
        try {
            await inventoryAPI.purchaseItem({
                id: inventoryItem.id,
                purchase_quantity: inventoryItem.purchase_quantity,
            });
            globalStore.showSuccess("Done!", ["Successfully item purchased!"]);
            clear();
            getItems();
            purchaseItemRef.hide();
        } catch (error) {
            console.log(error);
            globalStore.showError(error);
        }
    };

    const clear = () => {
        inventoryItem.id = "";
        inventoryItem.item = "";
        inventoryItem.quantity = "";
        inventoryItem.stock = "";
        inventoryItem.reorder_level = "";
        inventoryItem.purchase_price = "";
        inventoryItem.unit_of_measurement = "";
        inventoryItem.purchase_quantity = "";
    };

    return {
        inventoryItem,
        items,
        addItem,
        getItems,
        editItem,
        deleteItem,
        purchaseItem,
    };
}
