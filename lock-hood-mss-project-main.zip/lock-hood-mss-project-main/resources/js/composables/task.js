import taskAPI from "@/apis/taskAPI";
import { getPage } from "@/helpers/getPage";
import { useGlobalStore } from "@/stores/globalStore";
import { computed, reactive, ref } from "vue";

export default function useTask() {
    const tasks = ref([]);
    const totalCost = ref(0);
    const task = reactive({
        id: "",
        customer_id: "",
        title: "",
        workshop_id: "",
        required_space: "",
        workers_ids: [],
        materials: [],
        margin: "",
        estimated_time: "",
        estimated_time_unit: "",
        avaiableWorkspaces: "",
    });
    const globalStore = useGlobalStore();
    const currentlyShowingWorkers = ref(null);
    const currentlyShowingMaterials = ref(null);
    const editTask = ref(false);

    const addTask = async () => {
        try {
            await taskAPI.addTask(task);
            clear();
            globalStore.showSuccess("Done!", ["Successfully new task added"]);
            await getTasks();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getTasks = async (url) => {
        const page = getPage(url);
        try {
            tasks.value = await (await taskAPI.getTasks(page)).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getMaterialCost = (t) => {
        let cost = 0;
        for (let i = 0; i < t?.items.length; i++) {
            const item = t?.items[i];
            cost = +cost + +item.purchase_price * +item.pivot.required_amount;
        }
        return cost.toFixed(2);
    };

    const clear = () => {
        task.id = "";
        task.customer_id = "";
        task.title = "";
        task.workshop_id = "";
        task.required_space = "";
        task.workers_ids = [];
        task.materials = [];
        task.margin = "";
        task.estimated_time = "";
        task.estimated_time_unit = "";
        task.avaiableWorkspaces = "";
        totalCost.value = 0;
        editTask.value = false;
    };

    const addRequiredAmount = (el, id, edit = false, item = null) => {
        if (edit) {
            // document.getElementById(`${item.id}${item.stock}`).value =
            //     item.pivot.required_amount;
            globalStore.materials.data = globalStore.materials?.data?.map(
                (m) => {
                    if (m.id === item.id)
                        m["required_amount"] = item.pivot.required_amount;
                    return m;
                }
            );
            task.materials.push({
                amount: item.pivot.required_amount,
                id,
            });
        } else {
            const amount = el.target.value;
            if (amount != "" && Number(amount) > 0) {
                let alreadyFound = false;
                for (let i = 0; i < task.materials.length; i++) {
                    const mat = task.materials[i];
                    if (mat.id === id) {
                        alreadyFound = true;
                        task.materials[i].amount = amount;
                    }
                }
                if (!alreadyFound)
                    task.materials.push({
                        id,
                        amount,
                    });
            } else {
                if (id != "") {
                    task.materials = task.materials.filter((material) => {
                        return material.id !== id;
                    });
                }
            }
        }
    };

    const setEditTaskValues = (editingTask) => {
        clear();

        task.id = editingTask.id;
        task.customer_id = editingTask.order.customer_id;
        task.title = editingTask.title;
        task.workshop_id = editingTask.workshop[0].id;
        task.required_space = editingTask.working_line.required_space;
        task.workers_ids = editingTask.working_line.employees.map(
            (employee) => employee.id
        );

        editingTask.items.forEach((item) => {
            totalCost.value =
                +totalCost.value +
                +item.purchase_price * +item.pivot.required_amount;
            addRequiredAmount(true, item.id, true, item);
        });

        task.margin = editingTask.estimated_cost;
        totalCost.value = (+totalCost.value + +task.margin).toFixed(2);

        let createdDate = new Date(editingTask.created_at);
        let estimatedDate = new Date(editingTask.estimated_time);
        let difference = Math.abs(
            estimatedDate.getTime() - createdDate.getTime()
        );
        let diffDays = Math.ceil(difference / (1000 * 3600 * 24));
        if (diffDays < 7) {
            task.estimated_time = diffDays;
            task.estimated_time_unit = "days";
        } else if (diffDays >= 7 && diffDays < 30) {
            if ((diffDays / 7) % 1 === 0) {
                task.estimated_time = diffDays / 7;
                task.estimated_time_unit = "weeks";
            } else {
                task.estimated_time = diffDays;
                task.estimated_time_unit = "days";
            }
        } else if (diffDays >= 30 && diffDays < 365) {
            if ((diffDays / 30) % 1 === 0) {
                task.estimated_time = diffDays / 30;
                task.estimated_time_unit = "months";
            } else if ((diffDays / 7) % 1 === 0) {
                task.estimated_time = diffDays / 7;
                task.estimated_time_unit = "weeks";
            } else {
                task.estimated_time = diffDays;
                task.estimated_time_unit = "days";
            }
        } else if (diffDays >= 365) {
            if ((diffDays / 365) % 1 === 0) {
                task.estimated_time = diffDays / 365;
                task.estimated_time_unit = "years";
            } else if ((diffDays / 30) % 1 === 0) {
                task.estimated_time = diffDays / 30;
                task.estimated_time_unit = "months";
            } else if ((diffDays / 7) % 1 === 0) {
                task.estimated_time = diffDays / 7;
                task.estimated_time_unit = "weeks";
            } else {
                task.estimated_time = diffDays;
                task.estimated_time_unit = "days";
            }
        }
        editTask.value = true;
    };

    const updateTask = async (avaiableWorkspaces) => {
        try {
            task.avaiableWorkspaces = avaiableWorkspaces;
            await taskAPI.updateTask(task);
            await getTasks();
            clear();
            globalStore.showSuccess("Done!", ["Successfully task updated"]);
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const deleteTask = async () => {
        try {
            await taskAPI.deleteTask(task.id);
            await getTasks();
            clear();
            globalStore.showSuccess("Done!", ["Successfully task deleted"]);
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const doneTask = async () => {
        try {
            await taskAPI.doneTask(task.id);
            await getTasks();
            clear();
            globalStore.showSuccess("Done!", ["Task is successfully done!"]);
        } catch (error) {
            globalStore.showError(error);
        }
    };

    return {
        tasks,
        task,
        totalCost,
        currentlyShowingWorkers,
        currentlyShowingMaterials,
        editTask,
        doneTask,
        deleteTask,
        updateTask,
        addRequiredAmount,
        setEditTaskValues,
        addTask,
        getTasks,
        getMaterialCost,
    };
}
