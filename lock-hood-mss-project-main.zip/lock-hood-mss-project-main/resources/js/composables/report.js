import reportAPI from "@/apis/reportAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { reactive, ref } from "vue";

export default function useReport() {
    const globalStore = useGlobalStore();
    const incomeReport = ref({});
    const itemsBelowReorderLevel = ref([]);
    const dates = reactive({
        from: null,
        to: null,
    });
    const taskKPIs = ref([]);
    const materialUsedInTask = ref([]);
    const totalIncomeAndOutgoingOfAOrder = ref([]);
    const mostWorkedEmployees = ref([]);

    const getIncomeReport = async () => {
        dates.from === "" ? null : dates.from;
        dates.to === "" ? null : dates.to;
        try {
            incomeReport.value = (
                await reportAPI.incomeReport(dates.from, dates.to)
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getItemsBelowReorderLevel = async () => {
        try {
            itemsBelowReorderLevel.value = await (
                await reportAPI.getItemsBelowReorderLevel()
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getTaskKPIs = async () => {
        try {
            taskKPIs.value = await (await reportAPI.getTaskKPIs()).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getMaterialsUsedInTask = async () => {
        try {
            materialUsedInTask.value = await (
                await reportAPI.getMostUsedRawMaterials()
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getTotalIncomeAndOutgoingOfATask = async () => {
        try {
            totalIncomeAndOutgoingOfAOrder.value = (
                await reportAPI.getTotalIncomeOutgoingOfAOrder()
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getMostWorkedEmployees = async () => {
        try {
            mostWorkedEmployees.value = (
                await reportAPI.getMostWorkedEmployees()
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    return {
        incomeReport,
        dates,
        itemsBelowReorderLevel,
        taskKPIs,
        materialUsedInTask,
        totalIncomeAndOutgoingOfAOrder,
        mostWorkedEmployees,
        getMostWorkedEmployees,
        getTotalIncomeAndOutgoingOfATask,
        getMaterialsUsedInTask,
        getIncomeReport,
        getItemsBelowReorderLevel,
        getTaskKPIs,
    };
}
