import factoryAPI from "@/apis/factoryAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { reactive, ref } from "vue";

export default function useFactory() {
    const globalStore = useGlobalStore();
    const factory = reactive({
        id: "",
        manager_id: "",
        title: "",
    });
    const factories = ref();

    const getFactories = async () => {
        try {
            factories.value = await (await factoryAPI.getFactories()).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const addFactory = async (addFactoryModal) => {
        globalStore.primaryModal = addFactoryModal;
        try {
            await factoryAPI.addFactory(factory);
            globalStore.showSuccess("Done!", [
                "Successfully created a factory!",
            ]);
            addFactoryModal.hide();
            clear();
            await getFactories();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const editFactory = async (editFactoryModal) => {
        globalStore.primaryModal = editFactoryModal;
        try {
            await factoryAPI.editFactory(factory);
            globalStore.showSuccess("Done!", ["Successfully factory updated!"]);
            editFactoryModal.hide();
            clear();
            await getFactories();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const deleteFactory = async (deleteFactoryModal) => {
        globalStore.primaryModal = deleteFactoryModal;
        try {
            await factoryAPI.deleteFactory({
                id: factory.id,
                _method: "delete",
            });
            globalStore.showSuccess("Done!", ["Successfully factory deleted!"]);
            clear();
            deleteFactoryModal.hide();
            await getFactories();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const clear = () => {
        factory.id = "";
        factory.manager_id = "";
        factory.title = "";
    };

    return {
        factory,
        factories,
        getFactories,
        addFactory,
        editFactory,
        deleteFactory,
    };
}
