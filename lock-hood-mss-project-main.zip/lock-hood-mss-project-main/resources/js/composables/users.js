import { computed, reactive, ref } from "vue";
import usersAPI from "../apis/usersAPI";
import { useGlobalStore } from "@/stores/globalStore";
import { getPage } from "@/helpers/getPage";

export default function useUsers() {
    const users = ref([]);
    const globalStore = useGlobalStore();
    const user = reactive({
        id: "",
        first_name: "",
        last_name: "",
        email: "",
        phone: "",
        address1: "",
        address2: "",
        user_title: "",
        joined_date: "",
        status: "",
        password: "",
        password_confirmation: "",
    });

    const searchKeyword = ref(null);
    const userTitle = ref(null);

    const getUsers = async (url = null) => {
        if (searchKeyword.value === "") searchKeyword.value = null;
        const page = getPage(url);
        try {
            users.value = await (
                await usersAPI.getUsers(
                    userTitle.value,
                    searchKeyword.value,
                    page
                )
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const getManagersAndSupervisorsOnly = async (url = null) => {
        if (searchKeyword.value === "") searchKeyword.value = null;
        const page = getPage(url);
        try {
            users.value = (
                await usersAPI.getManagersAndSupervisorsOnly(
                    searchKeyword.value,
                    page
                )
            ).data;
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const editUser = async (editUserModal) => {
        globalStore.primaryModal = editUserModal;
        try {
            await usersAPI.updateUser(user);
            editUserModal.hide();
            globalStore.showSuccess("Done!", ["Successfully user updated!"]);
            clear();
            await getUsers();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const changeStatus = async (confirmationModal) => {
        globalStore.primaryModal = confirmationModal;
        try {
            await usersAPI.changeStatus(user.id);
            confirmationModal.hide();
            globalStore.showSuccess("Done!", ["Successfully user blocked!"]);
            clear();
            await getUsers();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const deleteUser = async (confirmationModal) => {
        globalStore.primaryModal = confirmationModal;
        try {
            await usersAPI.deleteUser(user.id);
            confirmationModal.hide();
            globalStore.showSuccess("Done!", ["Successfully user deleted!"]);
            clear();
            await getUsers();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const addUser = async (addUserModal) => {
        globalStore.primaryModal = addUserModal;
        try {
            await usersAPI.addUser(user);
            addUserModal.hide();
            globalStore.showSuccess("Done!", ["Successfully new user added!"]);
            clear();
            await getUsers();
        } catch (error) {
            globalStore.showError(error);
        }
    };

    const clear = () => {
        user.first_name = "";
        user.last_name = "";
        user.email = "";
        user.phone = "";
        user.address1 = "";
        user.address2 = "";
        user.user_title = "";
        user.joined_date = "";
        user.status = "";
        user.id = "";
        user.password = "";
        user.password_confirmation = "";
    };

    const availableEmployees = computed(() => {
        if (users?.value?.data?.length > 0) {
            return users?.value?.data?.map((u) => {
                u.already_working = u?.working_line[0]?.is_done == 0;
                return u;
            });
        }
        return [];
    });

    return {
        users,
        user,
        searchKeyword,
        userTitle,
        availableEmployees,
        getManagersAndSupervisorsOnly,
        getUsers,
        editUser,
        changeStatus,
        deleteUser,
        addUser,
    };
}
