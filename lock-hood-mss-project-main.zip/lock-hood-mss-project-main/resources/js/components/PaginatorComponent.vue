<!-- eslint-disable vue/no-v-html -->
<template>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <li
                v-for="(page, index) in items?.links"
                :key="index"
                class="page-item"
            >
                <button
                    :class="{ active: page.active }"
                    class="page-link"
                    @click="$emit('getItems', page.url)"
                    v-html="page.label"
                ></button>
            </li>
        </ul>
    </nav>
</template>

<script setup>
const props = defineProps({
    items: {
        type: Object,
        default() {
            return {};
        },
    },
});

defineEmits(["getItems"]);
</script>
