<template>
    <div :id="modalId" class="modal" tabindex="-1">
        <div class="modal-dialog" :class="modalSize">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">{{ title }}</h3>
                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                    ></button>
                </div>
                <div class="modal-body">
                    <slot name="body"></slot>
                </div>
                <div class="modal-footer">
                    <slot name="footer"></slot>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { Modal } from "bootstrap";
import { onMounted } from "vue";

const props = defineProps({
    modalId: {
        type: String,
        default: "",
    },
    title: {
        type: String,
        default: "",
    },
    modalSize: {
        type: String,
        default: "modal-lg",
    },
});

let modal;

onMounted(() => {
    modal = new Modal(document.getElementById(props.modalId));
});

const show = () => {
    modal?.show();
};
const hide = () => {
    modal?.hide();
};

defineExpose({ show, hide });
</script>
