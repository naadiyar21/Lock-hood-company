<template>
    <div class="card col-md-3" style="width: 18rem">
        <router-link :to="{ name: route }" class="text-decoration-none">
            <img
                :src="require(`../../images/${image}`)"
                style="width: 250px; height: 250px"
                class="card-img-top"
                :alt="route"
            />
            <div class="card-body">
                <h4 class="card-text text-center">{{ title }}</h4>
            </div>
        </router-link>
    </div>
</template>

<script setup>
const props = defineProps({
    route: {
        type: String,
        default: "",
    },
    image: {
        type: String,
        default: null,
    },
    title: {
        type: String,
        default: "",
    },
});
</script>
