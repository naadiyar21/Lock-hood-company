<template>
    <NavBar />
    <div
        id="messageModal"
        class="modal"
        tabindex="-1"
        aria-labelledby="messageModalLabel"
        aria-hidden="true"
    >
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 id="messageModalLabel" class="modal-title fs-5">
                        {{ globalStore.heading }}
                    </h1>
                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                    ></button>
                </div>
                <div class="modal-body">
                    <p
                        v-for="(msgs, i) in globalStore.messages"
                        :key="i"
                        class="tw-mb-4"
                    >
                        {{ msgs }}
                    </p>
                </div>
                <div class="modal-footer">
                    <button
                        type="button"
                        :class="{
                            'btn-danger': globalStore.status >= 400,
                            'btn-success': globalStore.status <= 400,
                        }"
                        class="btn"
                        @click="globalStore.hide()"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-4">
        <h4>{{ $route.meta.heading }}</h4>
        <hr v-if="$route.meta.heading" />
        <router-view></router-view>
    </div>
</template>

<script setup>
import * as bootstrap from "bootstrap";
import { onMounted } from "vue";
import NavBar from "./components/NavBar.vue";
import { useGlobalStore } from "./stores/globalStore";

const globalStore = useGlobalStore();

onMounted(() => {
    globalStore.modal = new bootstrap.Modal(
        document.getElementById("messageModal")
    );
});
</script>

<style></style>
